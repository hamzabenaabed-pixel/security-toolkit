Diagnostic collection finished.
Output directory: /sdcard/kernel_wifi_diag_20260711_200151
Please send the text files and config.gz if present.
