# 🏗️ هيكل BeEF Engine Pro

## 📐 نظرة عامة على المعمارية

```
┌─────────────────────────────────────────────────────────────────┐
│                      BeEF Engine Pro                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐       │
│  │   WebView    │◄──►│  JS Bridge   │◄──►│   Kotlin     │       │
│  │  (index.html)│    │ (AndroidBridge)│   │   Backend    │       │
│  └──────────────┘    └──────────────┘    └──────────────┘       │
│         │                                        │               │
│         │                                        ▼               │
│         │              ┌─────────────────────────────────┐      │
│         │              │        BeEF Server Core         │      │
│         │              ├─────────────────────────────────┤      │
│         │              │  ┌─────────┐  ┌─────────────┐  │      │
│         │              │  │  HTTP   │  │  WebSocket  │  │      │
│         │              │  │ Server  │  │   Server    │  │      │
│         │              │  └────┬────┘  └──────┬──────┘  │      │
│         │              │       │              │         │      │
│         │              │       ▼              ▼         │      │
│         │              │  ┌─────────────────────────┐   │      │
│         │              │  │    Session Manager     │   │      │
│         │              │  │   (Zombie Sessions)    │   │      │
│         │              │  └───────────┬─────────────┘   │      │
│         │              │              │                 │      │
│         │              │       ┌──────┴──────┐          │      │
│         │              │       ▼             ▼          │      │
│         │              │  ┌─────────┐  ┌───────────┐    │      │
│         │              │  │  Hook   │  │  Command  │    │      │
│         │              │  │Generator│  │Dispatcher │    │      │
│         │              │  └─────────┘  └───────────┘    │      │
│         │              └─────────────────────────────────┘      │
│         │                            │                          │
│         │                            ▼                          │
│         │              ┌─────────────────────────────────┐      │
│         │              │        Root Manager             │      │
│         │              │  (Magisk Module Integration)    │      │
│         │              └─────────────────────────────────┘      │
│         │                            │                          │
│         ▼                            ▼                          │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    Target Browsers                       │   │
│  │  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐     │   │
│  │  │ Chrome  │  │ Firefox │  │ Safari  │  │  Edge   │     │   │
│  │  │ Zombie  │  │ Zombie  │  │ Zombie  │  │ Zombie  │     │   │
│  │  └─────────┘  └─────────┘  └─────────┘  └─────────┘     │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔧 المكونات الأساسية

### 1️⃣ BeEF Server (`BeefServer.kt`)

```kotlin
// الخادم الرئيسي - يدير HTTP و WebSocket
class BeefServer(context: Context, port: Int = 3000) {
    val sessionManager: SessionManager      // إدارة الجلسات
    val commandDispatcher: CommandDispatcher // إرسال الأوامر
    val hookGenerator: HookGenerator         // توليد الـ Hook
    
    fun start(): Boolean    // بدء الخادم
    fun stop()              // إيقاف الخادم
    fun sendCommand(sid: String, command: String)  // إرسال أمر
}
```

**ماذا يفعل:**
- يستمع على المنفذ 3000 (أو أي منفذ تختاره)
- يستقبل طلبات HTTP من المتصفحات المُهيأة
- يدير اتصالات WebSocket للتواصل الحي
- يوجه الطلبات للمعالجات المناسبة

---

### 2️⃣ Session Manager (`SessionManager.kt`)

```kotlin
// إدارة جلسات المتصفحات المُهيأة (Zombies)
class SessionManager {
    fun getOrCreate(sid: String): ZombieSession
    fun getAll(): List<ZombieSession>
    fun onlineCount(): Int
}

data class ZombieSession(
    val sid: String,
    var ip: String,
    var userAgent: String,
    var pageUrl: String,
    var cookies: String,
    // ... المزيد
)
```

**ماذا يفعل:**
- يتتبع كل متصفح متصل
- يخزن بصمة المتصفح (Browser Fingerprint)
- يحدد حالة الاتصال (Online/Offline)
- يدير اتصالات WebSocket

---

### 3️⃣ Hook Generator (`HookGenerator.kt`)

```kotlin
// مولد سكربت الحقن
class HookGenerator(port: Int) {
    var obfuscate: Boolean = true
    var heartbeatInterval: Int = 5000
    
    fun generate(sid: String): String  // توليد الـ Hook
    fun getHookUrl(): String           // رابط الـ Hook
    fun getEmbedCode(): String         // كود التضمين
}
```

**ماذا يفعل:**
- يولد سكربت JavaScript ديناميكياً
- يضيف تشويش (Obfuscation) اختياري
- يضمن اتصال مستمر مع الخادم
- يجمع معلومات المتصفح

---

### 4️⃣ Command Dispatcher (`CommandDispatcher.kt`)

```kotlin
// مرسل الأوامر
class CommandDispatcher {
    fun queueCommand(sid: String, code: String): Command
    fun getPendingCommands(sid: String): List<String>
    fun setResult(commandId: String, result: String)
}

// أوامر جاهزة
object CommandTemplates {
    val GET_COOKIES: String
    val GET_PAGE_HTML: String
    val KEYLOGGER: String
    fun redirect(url: String): String
    fun injectHtml(html: String): String
}
```

**ماذا يفعل:**
- يضع الأوامر في طابور للتنفيذ
- يرسل الأوامر عبر HTTP أو WebSocket
- يستقبل نتائج التنفيذ
- يحتفظ بسجل الأوامر

---

### 5️⃣ Root Manager (`RootManager.kt`)

```kotlin
// إدارة صلاحيات الروت
object RootManager {
    fun isRooted(): Boolean
    fun hasMagisk(): Boolean
    fun executeRoot(command: String): RootResult
}

// عمليات الشبكة بالروت
object RootNetworkOps {
    fun openPort(port: Int): Boolean
    fun portForward(from: Int, to: Int): Boolean
}
```

**ماذا يفعل بالروت:**
| العملية | الوصف |
|---------|-------|
| **فتح المنافذ** | تجاوز قيود الجدار الناري |
| **التشغيل عند الإقلاع** | عبر وحدة Magisk |
| **الوصول للملفات** | قراءة/كتابة ملفات النظام |
| **تعطيل تحسين البطارية** | الحفاظ على الخدمة نشطة |
| **توجيه المنافذ** | Port Forwarding داخلي |

---

### 6️⃣ Magisk Module (`MagiskModule.kt`)

```kotlin
// وحدة Magisk للتشغيل التلقائي
class MagiskModule(context: Context) {
    fun install(): Boolean      // تثبيت الوحدة
    fun uninstall(): Boolean    // إلغاء التثبيت
    fun setEnabled(enabled: Boolean): Boolean
    fun getLogs(): String       // عرض السجلات
}
```

**ماذا تفعل الوحدة:**
```
الإقلاع → Magisk → service.sh → BeefEngineService → الخادم يعمل
```

---

## 🔄 تدفق البيانات

### 1. تدفق الـ Hook

```
┌──────────────┐     HTTP GET /hook.js     ┌──────────────┐
│    Target    │ ─────────────────────────► │    BeEF      │
│   Browser    │                            │   Server     │
│              │ ◄───────────────────────── │              │
│              │      hook.js (Generated)   │              │
└──────┬───────┘                            └──────────────┘
       │
       │ تنفيذ الـ Hook
       ▼
┌──────────────┐
│  BeEF.init() │
│  - fingerprint()
│  - beacon()
│  - connectWS()
│  - persist()
└──────────────┘
```

### 2. تدفق البيانات (Beacon)

```
┌──────────────┐   POST /hook + JSON Data   ┌──────────────┐
│    Zombie    │ ───────────────────────────►│    BeEF      │
│   Browser    │   {cookies, url, ua, ...}  │   Server     │
│              │                             │              │
│              │ ◄─────────────────────────  │              │
│              │   {status, commands: [...]} │              │
└──────────────┘                             └──────────────┘
```

### 3. تدفق الأوامر (WebSocket)

```
┌──────────────┐                            ┌──────────────┐
│    BeEF      │   {type: "command",        │    Zombie    │
│   Server     │    code: "alert('hi')"}    │   Browser    │
│              │ ───────────────────────────►│              │
│              │                             │   eval(code) │
│              │ ◄─────────────────────────  │              │
│              │   {type: "result",          │              │
│              │    result: "undefined"}     │              │
└──────────────┘                             └──────────────┘
```

---

## 📁 هيكل الملفات الكامل

```
android-project/
│
├── 📱 app/
│   ├── src/main/
│   │   │
│   │   ├── java/com/beef/engine/
│   │   │   │
│   │   │   ├── 🎯 MainActivity.kt
│   │   │   │   └── النشاط الرئيسي + WebView + JS Bridge
│   │   │   │
│   │   │   ├── 🔧 BeefEngineService.kt
│   │   │   │   └── خدمة خلفية للحفاظ على المحرك
│   │   │   │
│   │   │   ├── 📦 BeefApplication.kt
│   │   │   │   └── Application class + Notification Channels
│   │   │   │
│   │   │   ├── 🔄 BootReceiver.kt
│   │   │   │   └── استقبال حدث إعادة التشغيل
│   │   │   │
│   │   │   ├── 📂 core/
│   │   │   │   ├── BeefServer.kt       ← الخادم الرئيسي
│   │   │   │   ├── SessionManager.kt   ← إدارة الجلسات
│   │   │   │   ├── HookGenerator.kt    ← مولد الـ Hook
│   │   │   │   ├── CommandDispatcher.kt← مرسل الأوامر
│   │   │   │   └── WebSocketConnection.kt ← اتصال WS
│   │   │   │
│   │   │   └── 📂 root/
│   │   │       ├── RootManager.kt      ← إدارة الروت
│   │   │       └── MagiskModule.kt     ← وحدة Magisk
│   │   │
│   │   ├── assets/
│   │   │   └── index.html              ← واجهة المستخدم
│   │   │
│   │   └── AndroidManifest.xml
│   │
│   ├── build.gradle.kts
│   └── proguard-rules.pro
│
├── 🔐 keystore/
│   └── beef-release-key.jks
│
├── 📦 release/
│   └── BeefEngine-v2.0.0-release.apk
│
├── 🚀 build-apk.sh
├── 🚀 build-apk.bat
└── 📖 README.md
```

---

## ⚠️ ملاحظات أمنية

### ما يتطلب Root:
| الميزة | بدون Root | مع Root |
|--------|:---------:|:-------:|
| الخادم المحلي | ✅ | ✅ |
| التشغيل عند الإقلاع | ❌ | ✅ |
| فتح المنافذ < 1024 | ❌ | ✅ |
| تجاوز تحسين البطارية | محدود | ✅ |
| الوصول لملفات التطبيقات | ❌ | ✅ |

### بدون Root:
- الخادم يعمل بشكل كامل
- يمكن الوصول من نفس الشبكة
- التشغيل يدوي عند فتح التطبيق
- بعض القيود على المنافذ

### مع Root (Magisk):
- تشغيل تلقائي عند الإقلاع
- فتح أي منفذ
- عدم إيقاف الخدمة من النظام
- ميزات إضافية للشبكة

---

## 🎯 الاستخدام

```kotlin
// بدء المحرك
val server = BeefServer(context, 3000)
server.addListener(object : BeefServerListener {
    override fun onZombieUpdate(session: ZombieSession) {
        // متصفح جديد أو تحديث
    }
    override fun onCommandResult(sid: String, id: String, result: String) {
        // نتيجة أمر
    }
})
server.start()

// إرسال أمر
server.sendCommand(sessionId, "alert('Hello!')")

// استخدام قوالب الأوامر
server.sendCommand(sessionId, CommandTemplates.GET_COOKIES)
```

---

⚠️ **تذكير**: هذا للاستخدام التعليمي والبحثي فقط!
