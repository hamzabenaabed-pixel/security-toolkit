/**
 * Root Manager - مدير صلاحيات الروت
 * ====================================
 * 
 * يدير العمليات التي تتطلب صلاحيات الجذر (Root)
 * 
 * ⚠️ يتطلب جهاز بصلاحيات Root (Magisk/SuperSU)
 */

package com.beef.engine.root

import android.content.Context
import android.util.Log
import java.io.*

/**
 * مدير صلاحيات الروت
 */
object RootManager {
    
    private const val TAG = "RootManager"
    
    /**
     * التحقق من وجود صلاحيات الروت
     */
    fun isRooted(): Boolean {
        return checkRootMethod1() || checkRootMethod2() || checkRootMethod3()
    }
    
    /**
     * طريقة 1: البحث عن ملف su
     */
    private fun checkRootMethod1(): Boolean {
        val paths = arrayOf(
            "/system/bin/su",
            "/system/xbin/su",
            "/sbin/su",
            "/system/su",
            "/system/bin/.ext/.su",
            "/system/usr/we-need-root/su",
            "/system/xbin/mu",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/data/local/su"
        )
        
        for (path in paths) {
            if (File(path).exists()) {
                Log.d(TAG, "Found su at: $path")
                return true
            }
        }
        return false
    }
    
    /**
     * طريقة 2: البحث عن Magisk
     */
    private fun checkRootMethod2(): Boolean {
        val magiskPaths = arrayOf(
            "/sbin/.magisk",
            "/data/adb/magisk",
            "/data/adb/modules"
        )
        
        for (path in magiskPaths) {
            if (File(path).exists()) {
                Log.d(TAG, "Found Magisk at: $path")
                return true
            }
        }
        return false
    }
    
    /**
     * طريقة 3: محاولة تنفيذ أمر su
     */
    private fun checkRootMethod3(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec("su -c id")
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = reader.readLine()
            process.waitFor()
            output?.contains("uid=0") == true
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * التحقق من وجود Magisk
     */
    fun hasMagisk(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec("magisk -v")
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val version = reader.readLine()
            process.waitFor()
            !version.isNullOrEmpty()
        } catch (e: Exception) {
            false
        }
    }
    
    /**
     * الحصول على إصدار Magisk
     */
    fun getMagiskVersion(): String? {
        return try {
            val process = Runtime.getRuntime().exec("magisk -v")
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val version = reader.readLine()
            process.waitFor()
            version
        } catch (e: Exception) {
            null
        }
    }
    
    /**
     * تنفيذ أمر بصلاحيات الروت
     */
    fun executeRoot(command: String): RootResult {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            
            val stdout = BufferedReader(InputStreamReader(process.inputStream)).readText()
            val stderr = BufferedReader(InputStreamReader(process.errorStream)).readText()
            val exitCode = process.waitFor()
            
            RootResult(
                success = exitCode == 0,
                output = stdout,
                error = stderr,
                exitCode = exitCode
            )
        } catch (e: Exception) {
            Log.e(TAG, "Root command failed", e)
            RootResult(
                success = false,
                output = "",
                error = e.message ?: "Unknown error",
                exitCode = -1
            )
        }
    }
    
    /**
     * تنفيذ عدة أوامر بصلاحيات الروت
     */
    fun executeRootScript(commands: List<String>): RootResult {
        val script = commands.joinToString("\n")
        return executeRoot(script)
    }
    
    /**
     * قراءة ملف بصلاحيات الروت
     */
    fun readFileAsRoot(path: String): String? {
        val result = executeRoot("cat '$path'")
        return if (result.success) result.output else null
    }
    
    /**
     * كتابة ملف بصلاحيات الروت
     */
    fun writeFileAsRoot(path: String, content: String): Boolean {
        val escapedContent = content.replace("'", "'\\''")
        val result = executeRoot("echo '$escapedContent' > '$path'")
        return result.success
    }
    
    /**
     * نسخ ملف بصلاحيات الروت
     */
    fun copyFileAsRoot(source: String, destination: String): Boolean {
        val result = executeRoot("cp '$source' '$destination'")
        return result.success
    }
    
    /**
     * تغيير صلاحيات ملف
     */
    fun chmodAsRoot(path: String, permissions: String): Boolean {
        val result = executeRoot("chmod $permissions '$path'")
        return result.success
    }
    
    /**
     * تغيير مالك ملف
     */
    fun chownAsRoot(path: String, owner: String): Boolean {
        val result = executeRoot("chown $owner '$path'")
        return result.success
    }
}

/**
 * نتيجة أمر الروت
 */
data class RootResult(
    val success: Boolean,
    val output: String,
    val error: String,
    val exitCode: Int
)

/**
 * عمليات الشبكة بصلاحيات الروت
 */
object RootNetworkOps {
    
    /**
     * فتح منفذ في الجدار الناري
     */
    fun openPort(port: Int): Boolean {
        return RootManager.executeRoot(
            "iptables -A INPUT -p tcp --dport $port -j ACCEPT"
        ).success
    }
    
    /**
     * إغلاق منفذ في الجدار الناري
     */
    fun closePort(port: Int): Boolean {
        return RootManager.executeRoot(
            "iptables -D INPUT -p tcp --dport $port -j ACCEPT"
        ).success
    }
    
    /**
     * توجيه المنفذ (Port Forward)
     */
    fun portForward(fromPort: Int, toPort: Int): Boolean {
        return RootManager.executeRoot("""
            iptables -t nat -A PREROUTING -p tcp --dport $fromPort -j REDIRECT --to-port $toPort
        """.trimIndent()).success
    }
    
    /**
     * الحصول على جدول ARP
     */
    fun getArpTable(): String? {
        val result = RootManager.executeRoot("cat /proc/net/arp")
        return if (result.success) result.output else null
    }
    
    /**
     * الحصول على الاتصالات النشطة
     */
    fun getActiveConnections(): String? {
        val result = RootManager.executeRoot("netstat -tuln")
        return if (result.success) result.output else null
    }
    
    /**
     * تغيير إعدادات DNS
     */
    fun setDns(dnsServer: String): Boolean {
        return RootManager.executeRoot("""
            setprop net.dns1 $dnsServer
            ndc resolver setnetdns 0 "" $dnsServer
        """.trimIndent()).success
    }
}

/**
 * عمليات النظام بصلاحيات الروت
 */
object RootSystemOps {
    
    /**
     * إعادة تحميل الخدمات
     */
    fun reloadServices(): Boolean {
        return RootManager.executeRoot("am broadcast -a android.intent.action.BOOT_COMPLETED").success
    }
    
    /**
     * الحصول على قائمة العمليات
     */
    fun getProcessList(): String? {
        val result = RootManager.executeRoot("ps -A")
        return if (result.success) result.output else null
    }
    
    /**
     * إنهاء عملية
     */
    fun killProcess(pid: Int): Boolean {
        return RootManager.executeRoot("kill -9 $pid").success
    }
    
    /**
     * إنهاء تطبيق
     */
    fun forceStopApp(packageName: String): Boolean {
        return RootManager.executeRoot("am force-stop $packageName").success
    }
    
    /**
     * تثبيت APK بصمت
     */
    fun installApkSilently(apkPath: String): Boolean {
        return RootManager.executeRoot("pm install -r '$apkPath'").success
    }
    
    /**
     * إلغاء تثبيت تطبيق بصمت
     */
    fun uninstallAppSilently(packageName: String): Boolean {
        return RootManager.executeRoot("pm uninstall $packageName").success
    }
    
    /**
     * الحصول على معلومات البطارية
     */
    fun getBatteryInfo(): String? {
        val result = RootManager.executeRoot("dumpsys battery")
        return if (result.success) result.output else null
    }
    
    /**
     * تعطيل تحسين البطارية لتطبيق
     */
    fun disableBatteryOptimization(packageName: String): Boolean {
        return RootManager.executeRoot(
            "dumpsys deviceidle whitelist +$packageName"
        ).success
    }
}
