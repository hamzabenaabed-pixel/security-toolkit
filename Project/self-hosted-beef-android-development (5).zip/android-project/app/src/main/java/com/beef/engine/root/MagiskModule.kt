/**
 * Magisk Module Manager - مدير وحدات Magisk
 * ===========================================
 * 
 * إنشاء وإدارة وحدة Magisk لتشغيل BeEF عند الإقلاع
 */

package com.beef.engine.root

import android.content.Context
import android.util.Log
import java.io.File

/**
 * مدير وحدة Magisk
 */
class MagiskModule(private val context: Context) {
    
    companion object {
        private const val TAG = "MagiskModule"
        private const val MODULE_ID = "beef_engine"
        private const val MODULE_NAME = "BeEF Engine Service"
        private const val MODULE_VERSION = "2.0.0"
        private const val MODULE_VERSION_CODE = "200"
        
        // مسارات Magisk
        private const val MAGISK_MODULES_PATH = "/data/adb/modules"
        private const val MODULE_PATH = "$MAGISK_MODULES_PATH/$MODULE_ID"
    }
    
    /**
     * التحقق من تثبيت الوحدة
     */
    fun isInstalled(): Boolean {
        val result = RootManager.executeRoot("test -d '$MODULE_PATH' && echo 'exists'")
        return result.output.contains("exists")
    }
    
    /**
     * تثبيت وحدة Magisk
     */
    fun install(): Boolean {
        Log.i(TAG, "Installing Magisk module...")
        
        if (!RootManager.hasMagisk()) {
            Log.e(TAG, "Magisk not found!")
            return false
        }
        
        // إنشاء مجلد الوحدة
        val commands = mutableListOf<String>()
        
        // إنشاء المجلدات
        commands.add("mkdir -p '$MODULE_PATH'")
        
        // إنشاء module.prop
        val moduleProp = """
            id=$MODULE_ID
            name=$MODULE_NAME
            version=$MODULE_VERSION
            versionCode=$MODULE_VERSION_CODE
            author=BeEF Project
            description=Runs BeEF Engine server on boot (research/educational use only)
        """.trimIndent()
        
        commands.add("cat > '$MODULE_PATH/module.prop' << 'EOF'\n$moduleProp\nEOF")
        
        // إنشاء service.sh (يعمل عند الإقلاع)
        val serviceScript = generateServiceScript()
        commands.add("cat > '$MODULE_PATH/service.sh' << 'EOF'\n$serviceScript\nEOF")
        commands.add("chmod 755 '$MODULE_PATH/service.sh'")
        
        // إنشاء post-fs-data.sh (اختياري)
        val postFsScript = """
            #!/system/bin/sh
            # BeEF Engine - Post FS Data Script
            # This runs very early, before most services
            
            MODDIR=${'$'}{0%/*}
            
            # Set up logging
            exec > /data/local/tmp/beef_postfs.log 2>&1
            echo "BeEF post-fs-data started at $(date)"
        """.trimIndent()
        
        commands.add("cat > '$MODULE_PATH/post-fs-data.sh' << 'EOF'\n$postFsScript\nEOF")
        commands.add("chmod 755 '$MODULE_PATH/post-fs-data.sh'")
        
        // إنشاء uninstall.sh
        val uninstallScript = """
            #!/system/bin/sh
            # BeEF Engine - Uninstall Script
            
            # Stop service
            pkill -f "com.beef.engine"
            
            # Clean up
            rm -rf /data/local/tmp/beef_*.log
            
            echo "BeEF Engine module uninstalled"
        """.trimIndent()
        
        commands.add("cat > '$MODULE_PATH/uninstall.sh' << 'EOF'\n$uninstallScript\nEOF")
        commands.add("chmod 755 '$MODULE_PATH/uninstall.sh'")
        
        // تنفيذ الأوامر
        val result = RootManager.executeRootScript(commands)
        
        if (result.success) {
            Log.i(TAG, "Magisk module installed successfully")
            return true
        } else {
            Log.e(TAG, "Failed to install module: ${result.error}")
            return false
        }
    }
    
    /**
     * إلغاء تثبيت الوحدة
     */
    fun uninstall(): Boolean {
        Log.i(TAG, "Uninstalling Magisk module...")
        
        val result = RootManager.executeRoot("rm -rf '$MODULE_PATH'")
        
        if (result.success) {
            Log.i(TAG, "Magisk module uninstalled")
            return true
        } else {
            Log.e(TAG, "Failed to uninstall: ${result.error}")
            return false
        }
    }
    
    /**
     * تفعيل/تعطيل الوحدة
     */
    fun setEnabled(enabled: Boolean): Boolean {
        val disableFile = "$MODULE_PATH/disable"
        
        return if (enabled) {
            RootManager.executeRoot("rm -f '$disableFile'").success
        } else {
            RootManager.executeRoot("touch '$disableFile'").success
        }
    }
    
    /**
     * هل الوحدة مفعلة؟
     */
    fun isEnabled(): Boolean {
        val result = RootManager.executeRoot("test -f '$MODULE_PATH/disable' && echo 'disabled'")
        return !result.output.contains("disabled")
    }
    
    /**
     * توليد سكربت الخدمة
     */
    private fun generateServiceScript(): String {
        val packageName = context.packageName
        
        return """
            #!/system/bin/sh
            # BeEF Engine - Service Script
            # Runs after boot is complete
            
            MODDIR=${'$'}{0%/*}
            PACKAGE="$packageName"
            LOG_FILE="/data/local/tmp/beef_service.log"
            
            # Logging function
            log() {
                echo "$(date '+%Y-%m-%d %H:%M:%S') - ${'$'}1" >> ${'$'}LOG_FILE
            }
            
            # Wait for boot to complete
            while [ "$(getprop sys.boot_completed)" != "1" ]; do
                sleep 1
            done
            
            # Additional delay for system stability
            sleep 10
            
            log "BeEF Engine service starting..."
            
            # Check if app is installed
            if ! pm list packages | grep -q "${'$'}PACKAGE"; then
                log "ERROR: BeEF Engine app not installed!"
                exit 1
            fi
            
            # Disable battery optimization
            dumpsys deviceidle whitelist +${'$'}PACKAGE >> ${'$'}LOG_FILE 2>&1
            
            # Start the app service
            am startservice -n ${'$'}PACKAGE/.BeefEngineService >> ${'$'}LOG_FILE 2>&1
            
            if [ ${'$'}? -eq 0 ]; then
                log "BeEF Engine service started successfully"
            else
                log "Failed to start BeEF Engine service"
                
                # Fallback: start main activity
                am start -n ${'$'}PACKAGE/.MainActivity >> ${'$'}LOG_FILE 2>&1
            fi
            
            # Open firewall port
            iptables -A INPUT -p tcp --dport 3000 -j ACCEPT >> ${'$'}LOG_FILE 2>&1
            log "Firewall port 3000 opened"
            
            log "BeEF Engine service script completed"
        """.trimIndent()
    }
    
    /**
     * عرض سجلات الوحدة
     */
    fun getLogs(): String {
        val result = RootManager.executeRoot("cat /data/local/tmp/beef_service.log 2>/dev/null")
        return result.output.ifEmpty { "No logs available" }
    }
    
    /**
     * مسح السجلات
     */
    fun clearLogs(): Boolean {
        return RootManager.executeRoot("rm -f /data/local/tmp/beef_*.log").success
    }
}
