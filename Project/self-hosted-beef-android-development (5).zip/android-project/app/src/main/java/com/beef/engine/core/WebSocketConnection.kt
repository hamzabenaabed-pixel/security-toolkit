/**
 * WebSocket Connection - اتصال WebSocket
 * =========================================
 */

package com.beef.engine.core

import android.util.Log
import java.io.*
import java.net.Socket
import kotlin.experimental.and
import kotlin.experimental.xor

/**
 * اتصال WebSocket مع عميل
 */
class WebSocketConnection(
    private val socket: Socket,
    private val input: BufferedReader,
    private val output: BufferedOutputStream,
    val sid: String
) {
    companion object {
        private const val TAG = "WebSocketConnection"
        
        // أنواع إطارات WebSocket
        private const val OPCODE_TEXT = 0x01
        private const val OPCODE_BINARY = 0x02
        private const val OPCODE_CLOSE = 0x08
        private const val OPCODE_PING = 0x09
        private const val OPCODE_PONG = 0x0A
    }
    
    private val rawInput: InputStream = socket.getInputStream()
    private var isOpen = true
    
    /**
     * قراءة إطار WebSocket
     */
    fun readFrame(): String? {
        if (!isOpen || socket.isClosed) return null
        
        try {
            val firstByte = rawInput.read()
            if (firstByte == -1) return null
            
            val fin = (firstByte and 0x80) != 0
            val opcode = firstByte and 0x0F
            
            // معالجة أنواع الإطارات
            when (opcode) {
                OPCODE_CLOSE -> {
                    isOpen = false
                    return null
                }
                OPCODE_PING -> {
                    // إرسال Pong
                    sendPong()
                    return readFrame()
                }
                OPCODE_PONG -> {
                    return readFrame()
                }
            }
            
            val secondByte = rawInput.read()
            if (secondByte == -1) return null
            
            val masked = (secondByte and 0x80) != 0
            var payloadLength = (secondByte and 0x7F).toLong()
            
            // قراءة الطول الممتد
            when (payloadLength.toInt()) {
                126 -> {
                    val b1 = rawInput.read()
                    val b2 = rawInput.read()
                    payloadLength = ((b1 shl 8) or b2).toLong()
                }
                127 -> {
                    var length = 0L
                    for (i in 0..7) {
                        length = (length shl 8) or rawInput.read().toLong()
                    }
                    payloadLength = length
                }
            }
            
            // قراءة قناع البيانات
            val mask = if (masked) {
                ByteArray(4).also { rawInput.read(it) }
            } else null
            
            // قراءة البيانات
            val payload = ByteArray(payloadLength.toInt())
            var read = 0
            while (read < payloadLength) {
                val r = rawInput.read(payload, read, (payloadLength - read).toInt())
                if (r == -1) break
                read += r
            }
            
            // فك القناع
            if (masked && mask != null) {
                for (i in payload.indices) {
                    payload[i] = (payload[i] xor mask[i % 4])
                }
            }
            
            return String(payload, Charsets.UTF_8)
            
        } catch (e: Exception) {
            Log.e(TAG, "Error reading WebSocket frame", e)
            return null
        }
    }
    
    /**
     * إرسال رسالة نصية
     */
    fun send(message: String): Boolean {
        if (!isOpen || socket.isClosed) return false
        
        return try {
            val data = message.toByteArray(Charsets.UTF_8)
            val frame = createFrame(OPCODE_TEXT, data)
            
            synchronized(output) {
                output.write(frame)
                output.flush()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error sending WebSocket message", e)
            false
        }
    }
    
    /**
     * إرسال Pong
     */
    private fun sendPong() {
        try {
            val frame = createFrame(OPCODE_PONG, ByteArray(0))
            synchronized(output) {
                output.write(frame)
                output.flush()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error sending pong", e)
        }
    }
    
    /**
     * إنشاء إطار WebSocket
     */
    private fun createFrame(opcode: Int, data: ByteArray): ByteArray {
        val frame = ByteArrayOutputStream()
        
        // البايت الأول: FIN + opcode
        frame.write(0x80 or opcode)
        
        // البايت الثاني: طول البيانات (بدون قناع من الخادم)
        when {
            data.size <= 125 -> {
                frame.write(data.size)
            }
            data.size <= 65535 -> {
                frame.write(126)
                frame.write((data.size shr 8) and 0xFF)
                frame.write(data.size and 0xFF)
            }
            else -> {
                frame.write(127)
                for (i in 7 downTo 0) {
                    frame.write((data.size shr (i * 8)) and 0xFF)
                }
            }
        }
        
        // البيانات
        frame.write(data)
        
        return frame.toByteArray()
    }
    
    /**
     * إغلاق الاتصال
     */
    fun close() {
        isOpen = false
        try {
            // إرسال إطار إغلاق
            val frame = createFrame(OPCODE_CLOSE, ByteArray(0))
            output.write(frame)
            output.flush()
        } catch (e: Exception) {
            // تجاهل الأخطاء عند الإغلاق
        }
        
        try {
            socket.close()
        } catch (e: Exception) {
            // تجاهل
        }
    }
    
    /**
     * هل الاتصال مفتوح؟
     */
    fun isConnected(): Boolean = isOpen && !socket.isClosed
}
