/**
 * BeEF Engine Service - خدمة خلفية للمحرك
 * ==========================================
 * 
 * هذه الخدمة تعمل في الخلفية للحفاظ على المحرك نشطاً
 * حتى عند إغلاق التطبيق
 */

package com.beef.engine

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

class BeefEngineService : Service() {

    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var scheduler: ScheduledExecutorService
    private var isRunning = false

    companion object {
        const val CHANNEL_ID = "beef_engine_service_channel"
        const val NOTIFICATION_ID = 2001
        const val ACTION_START = "com.beef.engine.START"
        const val ACTION_STOP = "com.beef.engine.STOP"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        scheduler = Executors.newScheduledThreadPool(2)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
        }

        if (!isRunning) {
            isRunning = true
            startForeground(NOTIFICATION_ID, createNotification())
            acquireWakeLock()
            startEngine()
        }

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        isRunning = false
        releaseWakeLock()
        scheduler.shutdown()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "BeEF Engine Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "خدمة المحرك المدمج"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, BeefEngineService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("BeEF Engine")
            .setContentText("المحرك يعمل في الخلفية")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun acquireWakeLock() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "BeefEngine::ServiceWakeLock"
        ).apply {
            acquire(10*60*1000L) // 10 دقائق كحد أقصى
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let {
            if (it.isHeld) {
                it.release()
            }
        }
        wakeLock = null
    }

    private fun startEngine() {
        // محاكاة عمل المحرك
        scheduler.scheduleAtFixedRate({
            if (isRunning) {
                // هنا يمكن إضافة منطق المحرك الفعلي
                // مثل الاستماع للاتصالات، معالجة الأوامر، إلخ
                performEngineTask()
            }
        }, 0, 5, TimeUnit.SECONDS)
    }

    private fun performEngineTask() {
        // منطق المحرك
        android.util.Log.d("BeefEngine", "Engine heartbeat - ${System.currentTimeMillis()}")
    }
}
