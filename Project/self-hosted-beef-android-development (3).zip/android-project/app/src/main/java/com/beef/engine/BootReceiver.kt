/**
 * Boot Receiver - مستقبل إعادة التشغيل
 * =====================================
 * 
 * يبدأ المحرك تلقائياً عند إعادة تشغيل الجهاز
 */

package com.beef.engine

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON") {
            
            val prefs = context.getSharedPreferences("BeefEnginePrefs", Context.MODE_PRIVATE)
            val autoStart = prefs.getBoolean("auto_start", true)
            
            if (autoStart) {
                android.util.Log.d("BeefEngine", "Boot completed - Starting engine service")
                
                val serviceIntent = Intent(context, BeefEngineService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }
            }
        }
    }
}
