/**
 * BeEF Engine Pro - Native Android Application
 * =============================================
 * 
 * هذا الملف يحتوي على الكود الأساسي لتحويل واجهة HTML إلى تطبيق Android أصلي
 * باستخدام WebView مع Bridge للتواصل بين JavaScript و Kotlin
 * 
 * المتطلبات:
 * - Android Studio Arctic Fox أو أحدث
 * - Kotlin 1.8+
 * - minSdk 24
 * - targetSdk 34
 */

package com.beef.engine

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.*
import android.view.View
import android.view.WindowManager
import android.webkit.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var notificationManager: NotificationManagerCompat
    private val executor = Executors.newSingleThreadExecutor()
    
    companion object {
        const val CHANNEL_ID = "beef_engine_channel"
        const val NOTIFICATION_ID = 1001
        const val PREFS_NAME = "BeefEnginePrefs"
        const val KEY_ENGINE_RUNNING = "engine_running"
        const val KEY_SETTINGS = "settings"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // إعداد النافذة بدون شريط العنوان
        window.apply {
            decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            )
            statusBarColor = android.graphics.Color.parseColor("#050810")
            navigationBarColor = android.graphics.Color.parseColor("#0a0e17")
            addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        
        // إنشاء WebView
        webView = WebView(this).apply {
            layoutParams = android.view.ViewGroup.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                android.view.ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        setContentView(webView)
        
        // إعداد قناة الإشعارات
        createNotificationChannel()
        notificationManager = NotificationManagerCompat.from(this)
        
        // إعداد WebView
        setupWebView()
        
        // تحميل الصفحة
        loadApp()
        
        // طلب الأذونات
        requestPermissions()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            mediaPlaybackRequiresUserGesture = false
        }
        
        // إضافة JavaScript Interface
        webView.addJavascriptInterface(BeefJSInterface(this), "AndroidBridge")
        
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // تفعيل التواصل مع Android
                injectAndroidBridge()
            }
            
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return false
            }
        }
        
        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                consoleMessage?.let {
                    android.util.Log.d("BeefEngine", "${it.message()} -- ${it.sourceId()}:${it.lineNumber()}")
                }
                return true
            }
        }
    }

    private fun loadApp() {
        // تحميل من assets أو من ملف HTML محلي
        webView.loadUrl("file:///android_asset/index.html")
        // أو يمكن تحميل من الويب
        // webView.loadUrl("http://localhost:3000")
    }

    private fun injectAndroidBridge() {
        val js = """
            (function() {
                window.Android = {
                    showNotification: function(type, title, message) {
                        AndroidBridge.showNotification(type, title, message);
                    },
                    vibrate: function(pattern) {
                        AndroidBridge.vibrate(pattern);
                    },
                    playSound: function(type) {
                        AndroidBridge.playSound(type);
                    },
                    saveData: function(key, value) {
                        AndroidBridge.saveData(key, value);
                    },
                    loadData: function(key) {
                        return AndroidBridge.loadData(key);
                    },
                    getDeviceInfo: function() {
                        return AndroidBridge.getDeviceInfo();
                    },
                    startForegroundService: function() {
                        AndroidBridge.startForegroundService();
                    },
                    stopForegroundService: function() {
                        AndroidBridge.stopForegroundService();
                    },
                    copyToClipboard: function(text) {
                        AndroidBridge.copyToClipboard(text);
                    },
                    shareText: function(text) {
                        AndroidBridge.shareText(text);
                    }
                };
                console.log('Android Bridge initialized');
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "BeEF Engine"
            val descriptionText = "إشعارات المحرك والاتصالات"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 100, 50, 100)
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun requestPermissions() {
        val permissions = arrayOf(
            Manifest.permission.VIBRATE,
            Manifest.permission.INTERNET,
            Manifest.permission.ACCESS_NETWORK_STATE,
            Manifest.permission.FOREGROUND_SERVICE
        )
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) 
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(
                    this, 
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS), 
                    100
                )
            }
        }
        
        permissions.forEach { permission ->
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(permission), 101)
            }
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            // إظهار حوار التأكيد قبل الخروج
            webView.evaluateJavascript(
                "if(typeof showExitDialog === 'function') showExitDialog(); else confirm('هل تريد الخروج؟') && Android.finish();",
                null
            )
        }
    }

    override fun onDestroy() {
        webView.destroy()
        executor.shutdown()
        super.onDestroy()
    }

    override fun onPause() {
        webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    // ==================== JavaScript Interface ====================
    
    inner class BeefJSInterface(private val context: Context) {
        
        private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        private val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

        @JavascriptInterface
        fun showNotification(type: String, title: String, message: String) {
            val iconRes = when (type) {
                "success" -> android.R.drawable.ic_dialog_info
                "error" -> android.R.drawable.ic_dialog_alert
                "warning" -> android.R.drawable.ic_dialog_alert
                else -> android.R.drawable.ic_dialog_info
            }
            
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            val pendingIntent = PendingIntent.getActivity(
                context, 0, intent, 
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            
            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(iconRes)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setVibrate(longArrayOf(0, 100, 50, 100))
            
            try {
                notificationManager.notify(System.currentTimeMillis().toInt(), builder.build())
            } catch (e: SecurityException) {
                e.printStackTrace()
            }
        }

        @JavascriptInterface
        fun vibrate(pattern: String) {
            try {
                val patternArray = pattern.split(",").map { it.trim().toLong() }.toLongArray()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createWaveform(patternArray, -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(patternArray, -1)
                }
            } catch (e: Exception) {
                // اهتزاز بسيط كبديل
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(100)
                }
            }
        }

        @JavascriptInterface
        fun playSound(type: String) {
            executor.execute {
                try {
                    val toneType = when (type) {
                        "success" -> ToneGenerator.TONE_PROP_ACK
                        "error" -> ToneGenerator.TONE_PROP_NACK
                        "warning" -> ToneGenerator.TONE_PROP_BEEP
                        else -> ToneGenerator.TONE_PROP_BEEP2
                    }
                    val toneGenerator = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
                    toneGenerator.startTone(toneType, 150)
                    Thread.sleep(200)
                    toneGenerator.release()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        @JavascriptInterface
        fun saveData(key: String, value: String) {
            prefs.edit().putString(key, value).apply()
        }

        @JavascriptInterface
        fun loadData(key: String): String {
            return prefs.getString(key, "") ?: ""
        }

        @JavascriptInterface
        fun getDeviceInfo(): String {
            val info = JSONObject().apply {
                put("model", Build.MODEL)
                put("manufacturer", Build.MANUFACTURER)
                put("androidVersion", Build.VERSION.RELEASE)
                put("sdkVersion", Build.VERSION.SDK_INT)
                put("device", Build.DEVICE)
                put("product", Build.PRODUCT)
                put("brand", Build.BRAND)
            }
            return info.toString()
        }

        @JavascriptInterface
        fun startForegroundService() {
            val intent = Intent(context, BeefEngineService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        @JavascriptInterface
        fun stopForegroundService() {
            val intent = Intent(context, BeefEngineService::class.java)
            context.stopService(intent)
        }

        @JavascriptInterface
        fun copyToClipboard(text: String) {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            val clip = android.content.ClipData.newPlainText("BeEF", text)
            clipboard.setPrimaryClip(clip)
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(context, "تم النسخ", Toast.LENGTH_SHORT).show()
            }
        }

        @JavascriptInterface
        fun shareText(text: String) {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            context.startActivity(Intent.createChooser(intent, "مشاركة"))
        }

        @JavascriptInterface
        fun finish() {
            Handler(Looper.getMainLooper()).post {
                (context as? MainActivity)?.finish()
            }
        }
    }
}
