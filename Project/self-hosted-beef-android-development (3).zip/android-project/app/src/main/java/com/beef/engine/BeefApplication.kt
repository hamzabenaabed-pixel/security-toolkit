/**
 * BeEF Engine Application Class
 * ==============================
 * 
 * الكلاس الرئيسي للتطبيق - يتم تهيئته عند بدء التطبيق
 */

package com.beef.engine

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build

class BeefApplication : Application() {

    companion object {
        lateinit var instance: BeefApplication
            private set
        
        const val CHANNEL_GENERAL = "beef_general"
        const val CHANNEL_ENGINE = "beef_engine"
        const val CHANNEL_ALERTS = "beef_alerts"
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        
        createNotificationChannels()
        initializeApp()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // قناة الإشعارات العامة
            val generalChannel = NotificationChannel(
                CHANNEL_GENERAL,
                "إشعارات عامة",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "إشعارات عامة من التطبيق"
            }

            // قناة المحرك
            val engineChannel = NotificationChannel(
                CHANNEL_ENGINE,
                "المحرك",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "حالة المحرك والخدمة الخلفية"
                setShowBadge(false)
            }

            // قناة التنبيهات المهمة
            val alertsChannel = NotificationChannel(
                CHANNEL_ALERTS,
                "تنبيهات مهمة",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "تنبيهات الاتصالات والأحداث المهمة"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 100, 50, 100, 50, 100)
            }

            notificationManager.createNotificationChannels(
                listOf(generalChannel, engineChannel, alertsChannel)
            )
        }
    }

    private fun initializeApp() {
        // تهيئة إعدادات التطبيق
        val prefs = getSharedPreferences("BeefEnginePrefs", Context.MODE_PRIVATE)
        
        // التحقق من التشغيل التلقائي
        if (prefs.getBoolean("auto_start", true)) {
            // يمكن تشغيل الخدمة هنا إذا لزم الأمر
        }

        android.util.Log.d("BeefEngine", "Application initialized")
    }
}
