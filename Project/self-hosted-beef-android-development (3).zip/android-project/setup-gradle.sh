#!/bin/bash

#############################################
#  Setup Gradle Wrapper
#############################################

echo "Setting up Gradle Wrapper..."

# Check if gradle is installed
if command -v gradle &> /dev/null; then
    echo "Gradle found, generating wrapper..."
    gradle wrapper --gradle-version 8.4
else
    echo "Gradle not found, downloading wrapper..."
    
    # Create wrapper directory
    mkdir -p gradle/wrapper
    
    # Download gradle-wrapper.jar
    WRAPPER_URL="https://github.com/gradle/gradle/raw/v8.4.0/gradle/wrapper/gradle-wrapper.jar"
    
    if command -v curl &> /dev/null; then
        curl -L -o gradle/wrapper/gradle-wrapper.jar "$WRAPPER_URL"
    elif command -v wget &> /dev/null; then
        wget -O gradle/wrapper/gradle-wrapper.jar "$WRAPPER_URL"
    else
        echo "Please install curl or wget, or download gradle-wrapper.jar manually"
        echo "URL: $WRAPPER_URL"
        exit 1
    fi
    
    echo "Wrapper downloaded successfully"
fi

# Make gradlew executable
chmod +x gradlew

echo "Done! You can now run: ./gradlew assembleRelease"
