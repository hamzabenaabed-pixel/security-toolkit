@echo off
REM ############################################
REM  BeEF Engine Pro - APK Build Script (Windows)
REM ############################################

setlocal enabledelayedexpansion

echo.
echo ========================================
echo   BeEF Engine Pro - APK Builder
echo   Version 2.0.0
echo ========================================
echo.

REM Configuration
set APP_NAME=BeefEngine
set VERSION_NAME=2.0.0
set KEYSTORE_DIR=keystore
set KEYSTORE_FILE=%KEYSTORE_DIR%\beef-release-key.jks
set KEYSTORE_ALIAS=beef-key
set KEYSTORE_PASSWORD=BeEF@2024#Secure
set KEY_PASSWORD=BeEF@2024#Secure
set OUTPUT_DIR=release

REM Check Java
echo [1/7] Checking Java...
java -version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Java not found! Please install JDK 17+
    pause
    exit /b 1
)
echo OK: Java found

REM Create assets directory and copy index.html
echo [2/7] Copying assets...
if not exist "app\src\main\assets" mkdir "app\src\main\assets"
if exist "..\index.html" (
    copy "..\index.html" "app\src\main\assets\" >nul
    echo OK: Copied index.html
) else if exist "index.html" (
    copy "index.html" "app\src\main\assets\" >nul
    echo OK: Copied index.html
) else (
    echo ERROR: index.html not found!
    pause
    exit /b 1
)

REM Generate keystore if not exists
echo [3/7] Setting up keystore...
if not exist "%KEYSTORE_DIR%" mkdir "%KEYSTORE_DIR%"
if not exist "%KEYSTORE_FILE%" (
    echo Generating new keystore...
    keytool -genkeypair -v -keystore "%KEYSTORE_FILE%" -keyalg RSA -keysize 2048 -validity 10000 -alias %KEYSTORE_ALIAS% -storepass %KEYSTORE_PASSWORD% -keypass %KEY_PASSWORD% -dname "CN=BeEF Engine, OU=Security Research, O=BeEF Project, L=Unknown, ST=Unknown, C=XX"
    echo OK: Keystore generated
) else (
    echo OK: Keystore exists
)

REM Build APK
echo [4/7] Building APK...
call gradlew.bat clean assembleRelease --no-daemon
if %errorlevel% neq 0 (
    echo ERROR: Build failed!
    pause
    exit /b 1
)
echo OK: APK built

REM Create output directory
if not exist "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"

REM Sign APK
echo [5/7] Signing APK...
set UNSIGNED_APK=app\build\outputs\apk\release\app-release-unsigned.apk
set SIGNED_APK=%OUTPUT_DIR%\%APP_NAME%-v%VERSION_NAME%-signed.apk
set FINAL_APK=%OUTPUT_DIR%\%APP_NAME%-v%VERSION_NAME%-release.apk

if not exist "%UNSIGNED_APK%" (
    set UNSIGNED_APK=app\build\outputs\apk\release\app-release.apk
)

REM Use jarsigner
copy "%UNSIGNED_APK%" "%SIGNED_APK%" >nul
jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 -keystore "%KEYSTORE_FILE%" -storepass %KEYSTORE_PASSWORD% -keypass %KEY_PASSWORD% "%SIGNED_APK%" %KEYSTORE_ALIAS%
echo OK: APK signed

REM Align APK (if zipalign available)
echo [6/7] Finalizing APK...
move "%SIGNED_APK%" "%FINAL_APK%" >nul
echo OK: APK ready

REM Verify
echo [7/7] Verifying APK...
jarsigner -verify "%FINAL_APK%"

echo.
echo ========================================
echo   BUILD SUCCESSFUL!
echo ========================================
echo.
echo APK Location: %FINAL_APK%
echo.
echo To install: adb install %FINAL_APK%
echo.

set /p INSTALL="Install now? (y/n): "
if /i "%INSTALL%"=="y" (
    adb install -r "%FINAL_APK%"
)

pause
