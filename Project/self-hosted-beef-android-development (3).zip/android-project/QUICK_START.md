# ⚡ البدء السريع - 5 دقائق

## 🖥️ الطريقة 1: باستخدام Android Studio (الأسهل)

### 1. افتح Android Studio
```
File → Open → اختر مجلد android-project
```

### 2. انتظر تحميل Gradle
> سيقوم Android Studio بتحميل كل الاعتماديات تلقائياً

### 3. انسخ index.html
```
انسخ الملف index.html إلى:
android-project/app/src/main/assets/index.html
```

### 4. ابنِ APK
```
Build → Generate Signed Bundle/APK → APK
```

### 5. أنشئ Keystore
```
Create new... 
- Path: keystore/beef-key.jks
- Password: اختر كلمة مرور قوية
- Alias: beef-key
- Validity: 25 years
```

### 6. اختر Release وابنِ
```
✓ APK جاهز في: app/build/outputs/apk/release/
```

---

## 🖥️ الطريقة 2: سطر الأوامر (Linux/Mac)

```bash
cd android-project

# 1. إعداد Gradle
chmod +x setup-gradle.sh gradlew build-apk.sh
./setup-gradle.sh

# 2. بناء وتوقيع APK (كل شيء تلقائي!)
./build-apk.sh
```

**النتيجة:** `release/BeefEngine-v2.0.0-release.apk`

---

## 🖥️ الطريقة 3: سطر الأوامر (Windows)

```batch
cd android-project

REM بناء وتوقيع APK
build-apk.bat
```

---

## 📲 التثبيت على الهاتف

### عبر USB:
```bash
adb install release/BeefEngine-v2.0.0-release.apk
```

### بدون USB:
1. انقل APK للهاتف (WhatsApp, Telegram, Drive...)
2. فعّل "مصادر غير معروفة" في الإعدادات
3. افتح APK وثبّت

---

## ✅ تم!

التطبيق جاهز للاستخدام 🎉

---

## ❓ مشاكل شائعة

| المشكلة | الحل |
|---------|------|
| Java not found | ثبّت JDK 17 |
| SDK not found | افتح Android Studio أولاً |
| Gradle sync failed | File → Sync Project with Gradle |
| assets not found | انسخ index.html للمسار الصحيح |
