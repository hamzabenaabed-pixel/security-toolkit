#!/bin/bash

#############################################
#  BeEF Engine Pro - APK Build & Sign Script
#############################################

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Configuration
APP_NAME="BeefEngine"
PACKAGE_NAME="com.beef.engine"
VERSION_NAME="2.0.0"
VERSION_CODE="1"

KEYSTORE_DIR="keystore"
KEYSTORE_FILE="$KEYSTORE_DIR/beef-release-key.jks"
KEYSTORE_ALIAS="beef-key"
KEYSTORE_PASSWORD="BeEF@2024#Secure"
KEY_PASSWORD="BeEF@2024#Secure"

OUTPUT_DIR="release"
UNSIGNED_APK="app/build/outputs/apk/release/app-release-unsigned.apk"
SIGNED_APK="$OUTPUT_DIR/$APP_NAME-v$VERSION_NAME-signed.apk"
ALIGNED_APK="$OUTPUT_DIR/$APP_NAME-v$VERSION_NAME-release.apk"

echo -e "${PURPLE}"
echo "╔══════════════════════════════════════════╗"
echo "║      BeEF Engine Pro - APK Builder       ║"
echo "║            Version $VERSION_NAME                  ║"
echo "╚══════════════════════════════════════════╝"
echo -e "${NC}"

# Function: Check requirements
check_requirements() {
    echo -e "${CYAN}[1/7] Checking requirements...${NC}"
    
    # Check Java
    if ! command -v java &> /dev/null; then
        echo -e "${RED}✗ Java not found. Please install JDK 17+${NC}"
        exit 1
    fi
    echo -e "${GREEN}✓ Java found: $(java -version 2>&1 | head -n 1)${NC}"
    
    # Check keytool
    if ! command -v keytool &> /dev/null; then
        echo -e "${RED}✗ keytool not found. Please install JDK${NC}"
        exit 1
    fi
    echo -e "${GREEN}✓ keytool found${NC}"
    
    # Check for Android SDK
    if [ -z "$ANDROID_HOME" ] && [ -z "$ANDROID_SDK_ROOT" ]; then
        echo -e "${YELLOW}⚠ ANDROID_HOME not set. Trying common paths...${NC}"
        if [ -d "$HOME/Android/Sdk" ]; then
            export ANDROID_HOME="$HOME/Android/Sdk"
        elif [ -d "/usr/local/android-sdk" ]; then
            export ANDROID_HOME="/usr/local/android-sdk"
        fi
    fi
    
    BUILD_TOOLS="$ANDROID_HOME/build-tools"
    if [ -d "$BUILD_TOOLS" ]; then
        # Get latest build-tools version
        BUILD_TOOLS_VERSION=$(ls -1 "$BUILD_TOOLS" | sort -V | tail -n 1)
        ZIPALIGN="$BUILD_TOOLS/$BUILD_TOOLS_VERSION/zipalign"
        APKSIGNER="$BUILD_TOOLS/$BUILD_TOOLS_VERSION/apksigner"
        echo -e "${GREEN}✓ Android SDK found: $ANDROID_HOME${NC}"
        echo -e "${GREEN}✓ Build tools: $BUILD_TOOLS_VERSION${NC}"
    else
        echo -e "${YELLOW}⚠ Build tools not found. Will use jarsigner instead.${NC}"
        ZIPALIGN=""
        APKSIGNER=""
    fi
}

# Function: Copy assets
copy_assets() {
    echo -e "${CYAN}[2/7] Copying assets...${NC}"
    
    ASSETS_DIR="app/src/main/assets"
    mkdir -p "$ASSETS_DIR"
    
    # Copy index.html from parent directory if exists
    if [ -f "../index.html" ]; then
        cp "../index.html" "$ASSETS_DIR/"
        echo -e "${GREEN}✓ Copied index.html to assets${NC}"
    elif [ -f "index.html" ]; then
        cp "index.html" "$ASSETS_DIR/"
        echo -e "${GREEN}✓ Copied index.html to assets${NC}"
    else
        echo -e "${RED}✗ index.html not found!${NC}"
        echo -e "${YELLOW}Please copy index.html to: $ASSETS_DIR/${NC}"
        exit 1
    fi
}

# Function: Generate keystore
generate_keystore() {
    echo -e "${CYAN}[3/7] Setting up keystore...${NC}"
    
    mkdir -p "$KEYSTORE_DIR"
    
    if [ -f "$KEYSTORE_FILE" ]; then
        echo -e "${GREEN}✓ Keystore already exists${NC}"
    else
        echo -e "${YELLOW}Generating new keystore...${NC}"
        
        keytool -genkeypair \
            -v \
            -keystore "$KEYSTORE_FILE" \
            -keyalg RSA \
            -keysize 2048 \
            -validity 10000 \
            -alias "$KEYSTORE_ALIAS" \
            -storepass "$KEYSTORE_PASSWORD" \
            -keypass "$KEY_PASSWORD" \
            -dname "CN=BeEF Engine, OU=Security Research, O=BeEF Project, L=Unknown, ST=Unknown, C=XX"
        
        echo -e "${GREEN}✓ Keystore generated: $KEYSTORE_FILE${NC}"
        
        # Save keystore info
        cat > "$KEYSTORE_DIR/keystore-info.txt" << EOF
╔══════════════════════════════════════════╗
║         KEYSTORE INFORMATION             ║
║      ⚠️ KEEP THIS FILE SECURE! ⚠️        ║
╚══════════════════════════════════════════╝

File: $KEYSTORE_FILE
Alias: $KEYSTORE_ALIAS
Store Password: $KEYSTORE_PASSWORD
Key Password: $KEY_PASSWORD
Validity: 10000 days

Generated: $(date)

⚠️ WARNING: Keep this information safe!
   You need it to update your app later.
EOF
        echo -e "${YELLOW}⚠ Keystore info saved to: $KEYSTORE_DIR/keystore-info.txt${NC}"
    fi
}

# Function: Build APK
build_apk() {
    echo -e "${CYAN}[4/7] Building APK...${NC}"
    
    # Clean previous builds
    echo "Cleaning previous builds..."
    ./gradlew clean 2>/dev/null || true
    
    # Build release APK
    echo "Building release APK..."
    ./gradlew assembleRelease --no-daemon
    
    if [ -f "$UNSIGNED_APK" ]; then
        echo -e "${GREEN}✓ APK built successfully${NC}"
    else
        # Try alternative path
        UNSIGNED_APK="app/build/outputs/apk/release/app-release.apk"
        if [ -f "$UNSIGNED_APK" ]; then
            echo -e "${GREEN}✓ APK built successfully${NC}"
        else
            echo -e "${RED}✗ APK build failed!${NC}"
            exit 1
        fi
    fi
}

# Function: Sign APK
sign_apk() {
    echo -e "${CYAN}[5/7] Signing APK...${NC}"
    
    mkdir -p "$OUTPUT_DIR"
    
    if [ -n "$APKSIGNER" ] && [ -f "$APKSIGNER" ]; then
        # Use apksigner (recommended)
        echo "Using apksigner..."
        "$APKSIGNER" sign \
            --ks "$KEYSTORE_FILE" \
            --ks-key-alias "$KEYSTORE_ALIAS" \
            --ks-pass "pass:$KEYSTORE_PASSWORD" \
            --key-pass "pass:$KEY_PASSWORD" \
            --out "$SIGNED_APK" \
            "$UNSIGNED_APK"
    else
        # Fallback to jarsigner
        echo "Using jarsigner..."
        cp "$UNSIGNED_APK" "$SIGNED_APK"
        jarsigner \
            -verbose \
            -sigalg SHA256withRSA \
            -digestalg SHA-256 \
            -keystore "$KEYSTORE_FILE" \
            -storepass "$KEYSTORE_PASSWORD" \
            -keypass "$KEY_PASSWORD" \
            "$SIGNED_APK" \
            "$KEYSTORE_ALIAS"
    fi
    
    echo -e "${GREEN}✓ APK signed successfully${NC}"
}

# Function: Align APK
align_apk() {
    echo -e "${CYAN}[6/7] Aligning APK...${NC}"
    
    if [ -n "$ZIPALIGN" ] && [ -f "$ZIPALIGN" ]; then
        "$ZIPALIGN" -v -p 4 "$SIGNED_APK" "$ALIGNED_APK"
        rm "$SIGNED_APK"
        echo -e "${GREEN}✓ APK aligned successfully${NC}"
    else
        # Skip alignment if zipalign not available
        mv "$SIGNED_APK" "$ALIGNED_APK"
        echo -e "${YELLOW}⚠ Skipped alignment (zipalign not found)${NC}"
    fi
}

# Function: Verify APK
verify_apk() {
    echo -e "${CYAN}[7/7] Verifying APK...${NC}"
    
    if [ -n "$APKSIGNER" ] && [ -f "$APKSIGNER" ]; then
        "$APKSIGNER" verify -v "$ALIGNED_APK"
    else
        jarsigner -verify -verbose "$ALIGNED_APK"
    fi
    
    # Get APK info
    APK_SIZE=$(du -h "$ALIGNED_APK" | cut -f1)
    
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║          ✓ BUILD SUCCESSFUL!             ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${BLUE}APK Location:${NC} $ALIGNED_APK"
    echo -e "${BLUE}APK Size:${NC} $APK_SIZE"
    echo ""
    echo -e "${YELLOW}To install on device:${NC}"
    echo -e "  adb install $ALIGNED_APK"
    echo ""
    echo -e "${YELLOW}To install directly (if device connected):${NC}"
    read -p "Install now? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        adb install -r "$ALIGNED_APK" && echo -e "${GREEN}✓ Installed successfully!${NC}"
    fi
}

# Main execution
main() {
    cd "$(dirname "$0")"
    
    check_requirements
    copy_assets
    generate_keystore
    build_apk
    sign_apk
    align_apk
    verify_apk
}

main "$@"
