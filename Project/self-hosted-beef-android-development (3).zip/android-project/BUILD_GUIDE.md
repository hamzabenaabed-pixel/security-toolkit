# 📱 دليل بناء BeEF Engine Pro APK

## 📋 المتطلبات

### البرامج المطلوبة

| البرنامج | الإصدار | رابط التحميل |
|----------|---------|--------------|
| **JDK** | 17+ | [Oracle](https://www.oracle.com/java/technologies/downloads/) أو [OpenJDK](https://adoptium.net/) |
| **Android Studio** | 2023.1+ | [Download](https://developer.android.com/studio) |
| **Android SDK** | 34 | يأتي مع Android Studio |

### إعداد المتغيرات البيئية

#### Windows:
```batch
set JAVA_HOME=C:\Program Files\Java\jdk-17
set ANDROID_HOME=C:\Users\%USERNAME%\AppData\Local\Android\Sdk
set PATH=%PATH%;%JAVA_HOME%\bin;%ANDROID_HOME%\platform-tools
```

#### Linux/Mac:
```bash
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$JAVA_HOME/bin:$ANDROID_HOME/platform-tools
```

---

## 🚀 طريقة البناء السريعة (سكربت تلقائي)

### Linux/Mac:
```bash
cd android-project
chmod +x build-apk.sh
./build-apk.sh
```

### Windows:
```batch
cd android-project
build-apk.bat
```

---

## 🔧 طريقة البناء اليدوية

### الخطوة 1: نسخ ملف الواجهة
```bash
# تأكد من وجود index.html
mkdir -p app/src/main/assets
cp ../index.html app/src/main/assets/
```

### الخطوة 2: إنشاء Keystore للتوقيع
```bash
mkdir -p keystore

keytool -genkeypair \
    -v \
    -keystore keystore/beef-release-key.jks \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -alias beef-key \
    -storepass "BeEF@2024#Secure" \
    -keypass "BeEF@2024#Secure" \
    -dname "CN=BeEF Engine, OU=Security, O=BeEF, C=XX"
```

### الخطوة 3: بناء APK
```bash
# تنظيف البناء السابق
./gradlew clean

# بناء APK
./gradlew assembleRelease
```

### الخطوة 4: توقيع APK

#### باستخدام apksigner (موصى به):
```bash
# مسار أدوات البناء
BUILD_TOOLS=$ANDROID_HOME/build-tools/34.0.0

# التوقيع
$BUILD_TOOLS/apksigner sign \
    --ks keystore/beef-release-key.jks \
    --ks-key-alias beef-key \
    --ks-pass pass:BeEF@2024#Secure \
    --key-pass pass:BeEF@2024#Secure \
    --out release/BeefEngine-signed.apk \
    app/build/outputs/apk/release/app-release-unsigned.apk
```

#### باستخدام jarsigner (بديل):
```bash
jarsigner -verbose \
    -sigalg SHA256withRSA \
    -digestalg SHA-256 \
    -keystore keystore/beef-release-key.jks \
    -storepass "BeEF@2024#Secure" \
    app/build/outputs/apk/release/app-release-unsigned.apk \
    beef-key
```

### الخطوة 5: محاذاة APK
```bash
$BUILD_TOOLS/zipalign -v -p 4 \
    release/BeefEngine-signed.apk \
    release/BeefEngine-v2.0.0-release.apk
```

### الخطوة 6: التحقق
```bash
$BUILD_TOOLS/apksigner verify -v release/BeefEngine-v2.0.0-release.apk
```

---

## 📲 التثبيت

### عبر ADB (USB):
```bash
# تأكد من تفعيل USB Debugging على الهاتف
adb devices
adb install -r release/BeefEngine-v2.0.0-release.apk
```

### مباشرة على الهاتف:
1. انسخ APK إلى الهاتف
2. فعّل "تثبيت من مصادر غير معروفة"
3. افتح APK من مدير الملفات

---

## 🔐 معلومات Keystore

⚠️ **هام جداً**: احفظ هذه المعلومات في مكان آمن!

```
الملف:        keystore/beef-release-key.jks
الاسم المستعار: beef-key
كلمة المرور:   BeEF@2024#Secure
الصلاحية:      10000 يوم (~27 سنة)
```

> **ملاحظة**: إذا فقدت Keystore، لن تتمكن من تحديث التطبيق لاحقاً!

---

## 🔧 حل المشاكل

### خطأ: Java not found
```bash
# تأكد من تثبيت JDK 17
java -version

# إذا لم يكن مثبتاً:
# Ubuntu/Debian:
sudo apt install openjdk-17-jdk

# Mac:
brew install openjdk@17

# Windows: حمّل من Oracle أو Adoptium
```

### خطأ: SDK not found
```bash
# تأكد من إعداد ANDROID_HOME
echo $ANDROID_HOME

# إذا كان فارغاً، أضف للـ .bashrc أو .zshrc:
export ANDROID_HOME=$HOME/Android/Sdk
```

### خطأ: Gradle build failed
```bash
# تنظيف الكاش
./gradlew clean
rm -rf ~/.gradle/caches/

# إعادة المحاولة
./gradlew assembleRelease --refresh-dependencies
```

### خطأ: License not accepted
```bash
# قبول التراخيص
$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses
```

---

## 📁 هيكل الملفات بعد البناء

```
android-project/
├── app/
│   ├── build/
│   │   └── outputs/
│   │       └── apk/
│   │           ├── debug/
│   │           │   └── app-debug.apk
│   │           └── release/
│   │               └── app-release-unsigned.apk
│   └── src/main/assets/
│       └── index.html
├── keystore/
│   ├── beef-release-key.jks
│   └── keystore-info.txt
└── release/
    └── BeefEngine-v2.0.0-release.apk  ← APK النهائي
```

---

## 📊 معلومات APK

| العنصر | القيمة |
|--------|--------|
| Package | `com.beef.engine` |
| Version | 2.0.0 |
| Min SDK | 24 (Android 7.0) |
| Target SDK | 34 (Android 14) |
| الحجم المتوقع | ~3-5 MB |

---

## 🛡️ ملاحظات أمنية

1. **غيّر كلمة مرور Keystore** قبل الاستخدام الفعلي
2. **لا تشارك Keystore** مع أي شخص
3. **احتفظ بنسخة احتياطية** من Keystore
4. **استخدم HTTPS** في الإنتاج

---

## 📞 للمساعدة

إذا واجهت أي مشكلة:
1. تأكد من إعداد المتطلبات بشكل صحيح
2. راجع سجلات Gradle: `./gradlew assembleRelease --stacktrace`
3. جرب البناء من Android Studio مباشرة
