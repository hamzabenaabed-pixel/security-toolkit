# BeEF Engine Pro - Android Native

> ⚠️ **تحذير**: هذا التطبيق للاستخدام البحثي والتعليمي فقط. لا تستخدمه لأي غرض غير قانوني.

## 📱 نظرة عامة

تطبيق Android أصلي مبني بـ **Kotlin** مع واجهة مستخدم حديثة تتبع إرشادات **Material Design 3**.

## 🏗️ هيكل المشروع

```
android-project/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/beef/engine/
│   │   │   │   ├── MainActivity.kt          # النشاط الرئيسي + WebView
│   │   │   │   ├── BeefEngineService.kt     # خدمة خلفية
│   │   │   │   ├── BeefApplication.kt       # Application class
│   │   │   │   └── BootReceiver.kt          # مستقبل إعادة التشغيل
│   │   │   ├── assets/
│   │   │   │   └── index.html               # واجهة المستخدم (انسخ من المجلد الرئيسي)
│   │   │   ├── res/
│   │   │   │   ├── values/
│   │   │   │   │   ├── strings.xml
│   │   │   │   │   └── themes.xml
│   │   │   │   └── xml/
│   │   │   │       └── network_security_config.xml
│   │   │   └── AndroidManifest.xml
│   │   └── build.gradle.kts
│   └── proguard-rules.pro
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```

## 🚀 خطوات البناء

### 1. المتطلبات
- Android Studio Arctic Fox أو أحدث
- JDK 17
- Android SDK 34
- Kotlin 1.9+

### 2. إعداد المشروع

```bash
# استنساخ أو إنشاء مشروع جديد في Android Studio
# اختر: New Project > Empty Activity > Kotlin

# انسخ الملفات إلى المسارات المناسبة
```

### 3. نسخ ملف الواجهة

```bash
# انسخ index.html إلى مجلد assets
mkdir -p app/src/main/assets
cp ../index.html app/src/main/assets/
```

### 4. البناء

```bash
# من Terminal في Android Studio أو من سطر الأوامر
./gradlew assembleDebug

# للإصدار النهائي
./gradlew assembleRelease
```

### 5. التثبيت

```bash
# على جهاز متصل عبر USB
adb install app/build/outputs/apk/debug/app-debug.apk
```

## 🔧 الميزات

### JavaScript Bridge
التواصل بين الواجهة و Kotlin:

```javascript
// من JavaScript
Android.showNotification('success', 'عنوان', 'رسالة');
Android.vibrate('100,50,100');
Android.playSound('success');
Android.saveData('key', 'value');
const data = Android.loadData('key');
Android.copyToClipboard('نص');
Android.shareText('نص للمشاركة');
```

### الخدمة الخلفية
```kotlin
// تشغيل الخدمة
Android.startForegroundService()

// إيقاف الخدمة
Android.stopForegroundService()
```

## 📋 الأذونات

| الإذن | الوصف |
|-------|-------|
| INTERNET | الاتصال بالشبكة |
| VIBRATE | الاهتزاز |
| FOREGROUND_SERVICE | الخدمة الخلفية |
| POST_NOTIFICATIONS | الإشعارات |
| WAKE_LOCK | منع النوم |
| RECEIVE_BOOT_COMPLETED | التشغيل عند الإقلاع |

## 🎨 التخصيص

### تغيير الألوان
عدّل `res/values/themes.xml`:

```xml
<item name="colorPrimary">#EF4444</item>
<item name="colorSecondary">#10B981</item>
```

### تغيير الأيقونة
ضع الأيقونات في:
- `res/mipmap-mdpi/`
- `res/mipmap-hdpi/`
- `res/mipmap-xhdpi/`
- `res/mipmap-xxhdpi/`
- `res/mipmap-xxxhdpi/`

## 🔐 الأمان

1. **لا تُخزّن بيانات حساسة** في SharedPreferences بدون تشفير
2. **استخدم HTTPS** في الإنتاج
3. **فعّل ProGuard** في الإصدار النهائي
4. **راجع الأذونات** قبل النشر

## 📝 ملاحظات

- التطبيق يستخدم WebView لعرض الواجهة
- JavaScript Bridge يسمح بالتواصل الثنائي
- الخدمة الخلفية تحافظ على المحرك نشطاً
- يدعم التشغيل التلقائي عند إعادة تشغيل الجهاز

## 📄 الترخيص

للاستخدام البحثي والتعليمي فقط.

---

**⚠️ تنبيه قانوني**: استخدام هذا التطبيق لاختبار أنظمة بدون إذن صريح يُعد مخالفة قانونية.
